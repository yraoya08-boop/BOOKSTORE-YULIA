<?php
require_once 'config.php';
$pageTitle = 'Kategori';
$colorMap = ['blue' => 'cat-blue', 'yellow' => 'cat-yellow', 'green' => 'cat-green', 'purple' => 'cat-purple', 'pink' => 'cat-pink'];
$categories = $conn->query("SELECT * FROM categories ORDER BY name ASC");
require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Kategori</div>
  <h1>Semua Kategori</h1>
</div>

<section class="section">
  <div class="container">
    <div class="category-grid">
      <?php while ($cat = $categories->fetch_assoc()): ?>
        <a href="<?= BASE_URL ?>/books.php?category=<?= $cat['id'] ?>" class="category-card <?= $colorMap[$cat['color']] ?? 'cat-blue' ?>">
          <div class="icon-circle"><?= $cat['icon'] ?></div>
          <h3><?= esc($cat['name']) ?></h3>
          <?php $c = $conn->query("SELECT COUNT(*) c FROM books WHERE category_id=" . (int)$cat['id'])->fetch_assoc()['c']; ?>
          <p><?= $c ?> Buku</p>
        </a>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
