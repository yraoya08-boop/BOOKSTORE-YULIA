<?php
require_once 'config.php';
$pageTitle = 'Registrasi';

if (isLoggedIn()) {
    header('Location: ' . BASE_URL . '/index.php');
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm = $_POST['confirm_password'] ?? '';

    if ($name === '' || $email === '' || $password === '') {
        $errors[] = 'Semua field wajib diisi.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }
    if (strlen($password) < 6) {
        $errors[] = 'Password minimal 6 karakter.';
    }
    if ($password !== $confirm) {
        $errors[] = 'Konfirmasi password tidak cocok.';
    }

    if (!$errors) {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param('s', $email);
        $check->execute();
        if ($check->get_result()->num_rows > 0) {
            $errors[] = 'Email sudah terdaftar. Silakan login.';
        }
    }

    if (!$errors) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, phone, role) VALUES (?, ?, ?, ?, 'user')");
        $stmt->bind_param('ssss', $name, $email, $hash, $phone);
        if ($stmt->execute()) {
            setFlash('success', 'Registrasi berhasil! Silakan login.');
            header('Location: ' . BASE_URL . '/login.php');
            exit;
        } else {
            $errors[] = 'Terjadi kesalahan, silakan coba lagi.';
        }
    }
}

require 'includes/header.php';
?>

<div class="auth-wrap">
  <div class="auth-card">
    <h2>Buat Akun Baru</h2>
    <p class="sub">Daftar untuk mulai belanja buku di Nijbook</p>

    <?php foreach ($errors as $err): ?>
      <div class="alert alert-error"><?= esc($err) ?></div>
    <?php endforeach; ?>

    <form method="post">
      <div class="form-group">
        <label>Nama Lengkap</label>
        <input type="text" name="name" value="<?= esc($_POST['name'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" value="<?= esc($_POST['email'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label>No. Telepon</label>
        <input type="text" name="phone" value="<?= esc($_POST['phone'] ?? '') ?>">
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>
      <div class="form-group">
        <label>Konfirmasi Password</label>
        <input type="password" name="confirm_password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-full">Daftar Sekarang</button>
    </form>
    <div class="auth-foot">Sudah punya akun? <a href="<?= BASE_URL ?>/login.php">Login di sini</a></div>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
