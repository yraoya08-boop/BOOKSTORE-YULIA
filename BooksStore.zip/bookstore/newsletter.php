<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        setFlash('success', 'Terima kasih! Email kamu berhasil didaftarkan untuk update terbaru.');
    } else {
        setFlash('error', 'Email tidak valid.');
    }
}

header('Location: ' . BASE_URL . '/index.php');
exit;
