<?php
require_once 'config.php';
$pageTitle = 'Membership';
require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Membership</div>
  <h1>Remora Club Membership</h1>
</div>

<section class="section">
  <div class="container">
    <div class="remora-banner">
      <div>
        <h2>Gabung Remora Club</h2>
        <p>Nikmati berbagai keuntungan eksklusif hanya untuk member Remora — gratis ongkir, voucher spesial, akses awal buku terbaru, dan poin reward di setiap transaksi.</p>
        <?php if (isLoggedIn()): ?>
          <a href="<?= BASE_URL ?>/books.php" class="btn btn-primary">Mulai Belanja</a>
        <?php else: ?>
          <a href="<?= BASE_URL ?>/register.php" class="btn btn-primary">Gabung Sekarang</a>
        <?php endif; ?>
      </div>
      <div class="remora-perks">
        <div class="perk-card"><div class="perk-icon">🚚</div><h4>Gratis Ongkir</h4><p>Gratis ongkir untuk setiap pembelian</p></div>
        <div class="perk-card"><div class="perk-icon">🎁</div><h4>Voucher Eksklusif</h4><p>Dapatkan voucher diskon spesial</p></div>
        <div class="perk-card"><div class="perk-icon">🕒</div><h4>Akses Lebih Awal</h4><p>Akses lebih awal untuk buku terbaru</p></div>
        <div class="perk-card"><div class="perk-icon">⭐</div><h4>Poin Member</h4><p>Kumpulkan poin dan tukar hadiah</p></div>
      </div>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
