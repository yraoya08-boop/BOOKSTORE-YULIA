<?php
// includes/admin_header.php
// Harus dipanggil setelah requireAdmin() dan config.php di-include.
$current = basename($_SERVER['PHP_SELF']);
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? esc($pageTitle) . ' - Admin Nijbook' : 'Admin Nijbook' ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>
<div class="admin-layout">
  <aside class="admin-sidebar">
    <div class="logo">📖 Nijbook Admin</div>
    <a href="<?= BASE_URL ?>/admin/index.php" class="<?= $current === 'index.php' ? 'active' : '' ?>">📊 Dashboard</a>
    <a href="<?= BASE_URL ?>/admin/categories.php" class="<?= $current === 'categories.php' ? 'active' : '' ?>">🏷️ Kategori Buku</a>
    <a href="<?= BASE_URL ?>/admin/books.php" class="<?= $current === 'books.php' ? 'active' : '' ?>">📚 Data Buku</a>
    <a href="<?= BASE_URL ?>/admin/users.php" class="<?= $current === 'users.php' ? 'active' : '' ?>">👥 Data User</a>
    <a href="<?= BASE_URL ?>/admin/orders.php" class="<?= $current === 'orders.php' ? 'active' : '' ?>">📦 Pesanan</a>
    <a href="<?= BASE_URL ?>/admin/messages.php" class="<?= $current === 'messages.php' ? 'active' : '' ?>">✉️ Pesan Masuk</a>
    <a href="<?= BASE_URL ?>/index.php">🏠 Lihat Toko</a>
    <a href="<?= BASE_URL ?>/logout.php">🚪 Keluar</a>
  </aside>

  <main class="admin-main">
    <div class="admin-topbar">
      <h1><?= isset($pageTitle) ? esc($pageTitle) : 'Dashboard' ?></h1>
      <span style="font-size:14px; color:var(--text-gray);">👤 <?= esc($_SESSION['user_name']) ?></span>
    </div>

    <?php if ($flash): ?>
      <div class="alert alert-<?= esc($flash['type']) ?>"><?= esc($flash['message']) ?></div>
    <?php endif; ?>
