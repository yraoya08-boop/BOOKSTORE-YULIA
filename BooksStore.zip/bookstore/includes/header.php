<?php
// includes/header.php
// Pastikan config.php sudah di-include SEBELUM file ini di setiap halaman.
$current = basename($_SERVER['PHP_SELF']);
$flash = getFlash();
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= isset($pageTitle) ? esc($pageTitle) . ' - Nijbook' : 'Nijbook - Toko Buku Online' ?></title>
<link rel="stylesheet" href="<?= BASE_URL ?>/assets/css/style.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
</head>
<body>

<div class="promo-bar">
  <span>📦🔥 <strong>Diskon hingga 50%</strong> untuk member baru!</span>
  <a href="<?= BASE_URL ?>/register.php" class="promo-btn">Belanja Sekarang</a>
  <button class="promo-close">&times;</button>
</div>

<header class="navbar">
  <div class="container">
    <a href="<?= BASE_URL ?>/index.php" class="logo">
      <span class="logo-icon">📖</span> Nijbook
    </a>

    <nav class="nav-links">
      <a href="<?= BASE_URL ?>/index.php" class="<?= $current === 'index.php' ? 'active' : '' ?>">Beranda</a>
      <a href="<?= BASE_URL ?>/categories.php" class="<?= $current === 'categories.php' ? 'active' : '' ?>">Kategori</a>
      <a href="<?= BASE_URL ?>/books.php" class="<?= $current === 'books.php' || $current === 'book_detail.php' ? 'active' : '' ?>">Buku</a>
      <a href="<?= BASE_URL ?>/membership.php" class="<?= $current === 'membership.php' ? 'active' : '' ?>">Membership</a>
      <a href="<?= BASE_URL ?>/contact.php" class="<?= $current === 'contact.php' ? 'active' : '' ?>">Kontak</a>
    </nav>

    <form class="nav-search" action="<?= BASE_URL ?>/books.php" method="get">
      <input type="text" name="q" placeholder="Cari buku, penulis, atau genre..." value="<?= esc($_GET['q'] ?? '') ?>">
      <button type="submit">🔍</button>
    </form>

    <div class="nav-icons">
      <?php if (isLoggedIn()): ?>
        <?php if (isAdmin()): ?>
          <a href="<?= BASE_URL ?>/admin/index.php" title="Dashboard Admin">🛠️</a>
        <?php else: ?>
          <a href="<?= BASE_URL ?>/orders.php" title="Pesanan Saya">❤️</a>
        <?php endif; ?>
        <a href="<?= BASE_URL ?>/cart.php" title="Keranjang">
          🛍️
          <?php $cc = cartCount($conn); if ($cc > 0): ?>
            <span class="badge-count"><?= $cc ?></span>
          <?php endif; ?>
        </a>
        <a href="<?= BASE_URL ?>/profile.php" class="user-menu-name" title="Akun Saya">👤 <?= esc(explode(' ', $_SESSION['user_name'])[0]) ?></a>
        <a href="<?= BASE_URL ?>/logout.php" title="Keluar">🚪</a>
      <?php else: ?>
        <a href="<?= BASE_URL ?>/login.php" title="Login">👤</a>
        <a href="<?= BASE_URL ?>/login.php">🛍️</a>
      <?php endif; ?>
    </div>

    <button class="mobile-toggle">☰</button>
  </div>
</header>

<?php if ($flash): ?>
  <div class="container" style="padding-top:18px;">
    <div class="alert alert-<?= esc($flash['type']) ?>"><?= esc($flash['message']) ?></div>
  </div>
<?php endif; ?>
