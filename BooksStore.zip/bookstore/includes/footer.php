<?php
// includes/footer.php
// Banner Remora Club ditampilkan di semua halaman publik (tidak login sebagai admin)
if (!isAdmin()):
?>
<section class="section" style="padding-top:0;">
  <div class="container">
    <div class="remora-banner">
      <div>
        <h2>Gabung Remora Club</h2>
        <p>Nikmati berbagai keuntungan eksklusif hanya untuk member Remora.</p>
        <a href="<?= BASE_URL ?>/membership.php" class="btn btn-primary">Gabung Sekarang</a>
      </div>
      <div class="remora-perks">
        <div class="perk-card">
          <div class="perk-icon">🚚</div>
          <h4>Gratis Ongkir</h4>
          <p>Gratis ongkir untuk setiap pembelian</p>
        </div>
        <div class="perk-card">
          <div class="perk-icon">🎁</div>
          <h4>Voucher Eksklusif</h4>
          <p>Dapatkan voucher diskon spesial</p>
        </div>
        <div class="perk-card">
          <div class="perk-icon">🕒</div>
          <h4>Akses Lebih Awal</h4>
          <p>Akses lebih awal untuk buku terbaru</p>
        </div>
        <div class="perk-card">
          <div class="perk-icon">⭐</div>
          <h4>Poin Member</h4>
          <p>Kumpulkan poin dan tukar hadiah</p>
        </div>
      </div>
    </div>
  </div>
</section>

<section class="container" style="padding-bottom:40px;">
  <div class="newsletter">
    <div class="newsletter-left">
      <div class="newsletter-icon">✉️</div>
      <div>
        <h3>Stay Updated!</h3>
        <p>Dapatkan informasi terbaru tentang buku baru, promo menarik, dan event dari Nijbook.</p>
      </div>
    </div>
    <form class="newsletter-form" action="<?= BASE_URL ?>/newsletter.php" method="post">
      <input type="email" name="email" placeholder="Masukkan email kamu..." required>
      <button type="submit" class="btn btn-primary">Subscribe</button>
    </form>
  </div>
</section>
<?php endif; ?>

<footer class="footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <div class="footer-logo">📖 Nijbook</div>
        <p>Nijbook adalah toko buku online terpercaya yang menyediakan ribuan buku terbaik untuk menginspirasi harimu.</p>
        <div class="social-icons">
          <a href="#">📷</a>
          <a href="#">📘</a>
          <a href="#">🐦</a>
          <a href="#">▶️</a>
        </div>
      </div>
      <div>
        <h4>Toko</h4>
        <ul>
          <li><a href="<?= BASE_URL ?>/index.php">Beranda</a></li>
          <li><a href="<?= BASE_URL ?>/categories.php">Kategori</a></li>
          <li><a href="<?= BASE_URL ?>/books.php">Buku</a></li>
          <li><a href="<?= BASE_URL ?>/books.php?promo=1">Promo</a></li>
          <li><a href="<?= BASE_URL ?>/books.php?filter=bestseller">Bestseller</a></li>
        </ul>
      </div>
      <div>
        <h4>Informasi</h4>
        <ul>
          <li><a href="<?= BASE_URL ?>/about.php">Tentang Kami</a></li>
          <li><a href="<?= BASE_URL ?>/membership.php">Remora Club</a></li>
          <li><a href="#">Kebijakan Privasi</a></li>
          <li><a href="#">Syarat &amp; Ketentuan</a></li>
          <li><a href="#">FAQ</a></li>
        </ul>
      </div>
      <div>
        <h4>Bantuan</h4>
        <ul>
          <li><a href="#">Cara Belanja</a></li>
          <li><a href="#">Pembayaran</a></li>
          <li><a href="#">Pengiriman</a></li>
          <li><a href="<?= BASE_URL ?>/contact.php">Hubungi Kami</a></li>
        </ul>
      </div>
      <div>
        <h4>Kontak</h4>
        <p><strong>WhatsApp:</strong> +62 889-0504-7384</p>
        <p style="margin-top:8px;"><strong>Jam Operasional:</strong><br>Senin - Jumat, 09.00 - 18.00</p>
      </div>
    </div>
    <div class="footer-bottom">
      &copy; <?= date('Y') ?> Nijbook Bookstore. All rights reserved.
    </div>
  </div>
</footer>

<script src="<?= BASE_URL ?>/assets/js/script.js"></script>
</body>
</html>
