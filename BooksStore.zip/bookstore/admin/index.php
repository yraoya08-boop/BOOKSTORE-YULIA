<?php
require_once '../config.php';
requireAdmin();
$pageTitle = 'Dashboard';

$totalBooks = $conn->query("SELECT COUNT(*) c FROM books")->fetch_assoc()['c'];
$totalCategories = $conn->query("SELECT COUNT(*) c FROM categories")->fetch_assoc()['c'];
$totalUsers = $conn->query("SELECT COUNT(*) c FROM users WHERE role='user'")->fetch_assoc()['c'];
$totalOrders = $conn->query("SELECT COUNT(*) c FROM orders")->fetch_assoc()['c'];

$recentOrders = $conn->query("SELECT orders.*, users.name AS user_name FROM orders
                               JOIN users ON orders.user_id = users.id
                               ORDER BY orders.created_at DESC LIMIT 8");

require '../includes/admin_header.php';
?>

<div class="stat-cards">
  <div class="stat-card"><div class="num"><?= $totalBooks ?></div><div class="lbl">📚 Total Buku</div></div>
  <div class="stat-card"><div class="num"><?= $totalCategories ?></div><div class="lbl">🏷️ Total Kategori</div></div>
  <div class="stat-card"><div class="num"><?= $totalUsers ?></div><div class="lbl">👥 User Terdaftar</div></div>
  <div class="stat-card"><div class="num"><?= $totalOrders ?></div><div class="lbl">📦 Total Pesanan</div></div>
</div>

<div class="card-box">
  <h3>Pesanan Terbaru</h3>
  <table class="data-table">
    <thead>
      <tr><th>Order</th><th>User</th><th>Total</th><th>Status</th><th>Tanggal</th></tr>
    </thead>
    <tbody>
      <?php if ($recentOrders->num_rows === 0): ?>
        <tr><td colspan="5">Belum ada pesanan.</td></tr>
      <?php endif; ?>
      <?php while ($o = $recentOrders->fetch_assoc()): ?>
        <tr>
          <td>#<?= str_pad($o['id'], 5, '0', STR_PAD_LEFT) ?></td>
          <td><?= esc($o['user_name']) ?></td>
          <td><?= rupiah($o['total']) ?></td>
          <td><span class="status-pill status-<?= esc($o['status']) ?>"><?= esc($o['status']) ?></span></td>
          <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require '../includes/admin_footer.php'; ?>
