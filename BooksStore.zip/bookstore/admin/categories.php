<?php
require_once '../config.php';
requireAdmin();
$pageTitle = 'Kategori Buku';

$editData = null;

// ----- Delete -----
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    setFlash('success', 'Kategori berhasil dihapus.');
    header('Location: categories.php');
    exit;
}

// ----- Add / Update -----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $icon = trim($_POST['icon'] ?? '📚');
    $color = trim($_POST['color'] ?? 'blue');
    $description = trim($_POST['description'] ?? '');

    if ($name === '') {
        setFlash('error', 'Nama kategori wajib diisi.');
    } else {
        if ($id > 0) {
            $stmt = $conn->prepare("UPDATE categories SET name=?, icon=?, color=?, description=? WHERE id=?");
            $stmt->bind_param('ssssi', $name, $icon, $color, $description, $id);
            $stmt->execute();
            setFlash('success', 'Kategori berhasil diperbarui.');
        } else {
            $stmt = $conn->prepare("INSERT INTO categories (name, icon, color, description) VALUES (?, ?, ?, ?)");
            $stmt->bind_param('ssss', $name, $icon, $color, $description);
            $stmt->execute();
            setFlash('success', 'Kategori berhasil ditambahkan.');
        }
    }
    header('Location: categories.php');
    exit;
}

// ----- Edit mode: ambil data -----
if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $editData = $stmt->get_result()->fetch_assoc();
}

$categories = $conn->query("SELECT c.*, (SELECT COUNT(*) FROM books WHERE category_id = c.id) AS book_count FROM categories c ORDER BY c.id DESC");

require '../includes/admin_header.php';
?>

<div class="card-box">
  <h3><?= $editData ? 'Edit Kategori' : 'Tambah Kategori Baru' ?></h3>
  <form method="post">
    <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
    <div style="display:grid; grid-template-columns: 2fr 1fr 1fr; gap:16px;">
      <div class="form-group">
        <label>Nama Kategori</label>
        <input type="text" name="name" value="<?= esc($editData['name'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label>Icon (emoji)</label>
        <input type="text" name="icon" value="<?= esc($editData['icon'] ?? '📚') ?>">
      </div>
      <div class="form-group">
        <label>Warna</label>
        <select name="color">
          <?php foreach (['blue','yellow','green','purple','pink'] as $c): ?>
            <option value="<?= $c ?>" <?= (($editData['color'] ?? '') === $c) ? 'selected' : '' ?>><?= ucfirst($c) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
    </div>
    <div class="form-group">
      <label>Deskripsi</label>
      <input type="text" name="description" value="<?= esc($editData['description'] ?? '') ?>">
    </div>
    <button type="submit" class="btn btn-primary"><?= $editData ? 'Simpan Perubahan' : 'Tambah Kategori' ?></button>
    <?php if ($editData): ?><a href="categories.php" class="btn btn-outline" style="border-color:#d1d5db; color:#374151;">Batal</a><?php endif; ?>
  </form>
</div>

<div class="card-box">
  <h3>Daftar Kategori</h3>
  <table class="data-table">
    <thead><tr><th>Icon</th><th>Nama</th><th>Warna</th><th>Jumlah Buku</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php while ($cat = $categories->fetch_assoc()): ?>
        <tr>
          <td style="font-size:20px;"><?= $cat['icon'] ?></td>
          <td><?= esc($cat['name']) ?></td>
          <td><?= ucfirst($cat['color']) ?></td>
          <td><?= $cat['book_count'] ?></td>
          <td class="action-links">
            <a href="categories.php?edit=<?= $cat['id'] ?>" class="edit">Edit</a>
            <a href="categories.php?delete=<?= $cat['id'] ?>" class="delete confirm-delete" data-msg="Hapus kategori ini? Buku terkait akan kehilangan kategorinya.">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require '../includes/admin_footer.php'; ?>
