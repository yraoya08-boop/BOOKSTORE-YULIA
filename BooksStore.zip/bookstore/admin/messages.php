<?php
require_once '../config.php';
requireAdmin();
$pageTitle = 'Pesan Masuk';

if (isset($_GET['read'])) {
    $id = (int)$_GET['read'];
    $stmt = $conn->prepare("UPDATE messages SET is_read = 1 WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    header('Location: messages.php');
    exit;
}

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM messages WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    setFlash('success', 'Pesan dihapus.');
    header('Location: messages.php');
    exit;
}

$messages = $conn->query("SELECT * FROM messages ORDER BY created_at DESC");

require '../includes/admin_header.php';
?>

<div class="card-box">
  <h3>Pesan dari User (<?= $messages->num_rows ?>)</h3>
  <table class="data-table">
    <thead><tr><th>Status</th><th>Nama</th><th>Email</th><th>Subjek</th><th>Pesan</th><th>Tanggal</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php if ($messages->num_rows === 0): ?>
        <tr><td colspan="7">Belum ada pesan masuk.</td></tr>
      <?php endif; ?>
      <?php while ($m = $messages->fetch_assoc()): ?>
        <tr style="<?= $m['is_read'] ? '' : 'font-weight:700; background:#f8fafc;' ?>">
          <td><?= $m['is_read'] ? '✅' : '🔵 Baru' ?></td>
          <td><?= esc($m['name']) ?></td>
          <td><?= esc($m['email']) ?></td>
          <td><?= esc($m['subject'] ?: '-') ?></td>
          <td style="max-width:280px; white-space:normal;"><?= esc(mb_strimwidth($m['message'], 0, 120, '...')) ?></td>
          <td><?= date('d M Y, H:i', strtotime($m['created_at'])) ?></td>
          <td class="action-links">
            <?php if (!$m['is_read']): ?><a href="messages.php?read=<?= $m['id'] ?>" class="edit">Tandai Dibaca</a><?php endif; ?>
            <a href="messages.php?delete=<?= $m['id'] ?>" class="delete confirm-delete" data-msg="Hapus pesan ini?">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require '../includes/admin_footer.php'; ?>
