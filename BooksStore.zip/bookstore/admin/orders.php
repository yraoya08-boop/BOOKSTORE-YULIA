<?php
require_once '../config.php';
requireAdmin();
$pageTitle = 'Pesanan';

// ----- Update status pesanan -----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $orderId = (int)$_POST['order_id'];
    $status = $_POST['status'];
    $allowed = ['Diproses','Dikirim','Selesai','Dibatalkan'];
    if (in_array($status, $allowed)) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param('si', $status, $orderId);
        $stmt->execute();
        setFlash('success', 'Status pesanan #' . str_pad($orderId,5,'0',STR_PAD_LEFT) . ' berhasil diperbarui.');
    }
    header('Location: orders.php');
    exit;
}

$statusFilter = $_GET['status'] ?? '';
$sql = "SELECT orders.*, users.name AS user_name, users.email AS user_email FROM orders
        JOIN users ON orders.user_id = users.id";
if ($statusFilter) {
    $sql .= " WHERE orders.status = '" . $conn->real_escape_string($statusFilter) . "'";
}
$sql .= " ORDER BY orders.created_at DESC";
$orders = $conn->query($sql);

require '../includes/admin_header.php';
?>

<div class="card-box">
  <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:16px;">
    <h3 style="margin:0;">Semua Pesanan (<?= $orders->num_rows ?>)</h3>
    <div class="tabs">
      <a href="orders.php" class="tab-btn <?= $statusFilter==='' ? 'active':'' ?>">Semua</a>
      <?php foreach (['Diproses','Dikirim','Selesai','Dibatalkan'] as $s): ?>
        <a href="orders.php?status=<?= $s ?>" class="tab-btn <?= $statusFilter===$s ? 'active':'' ?>"><?= $s ?></a>
      <?php endforeach; ?>
    </div>
  </div>

  <table class="data-table">
    <thead><tr><th>Order</th><th>User</th><th>Email</th><th>Total</th><th>Pembayaran</th><th>Status</th><th>Tanggal</th><th>Ubah Status</th></tr></thead>
    <tbody>
      <?php if ($orders->num_rows === 0): ?>
        <tr><td colspan="8">Belum ada pesanan.</td></tr>
      <?php endif; ?>
      <?php while ($o = $orders->fetch_assoc()): ?>
        <tr>
          <td>#<?= str_pad($o['id'], 5, '0', STR_PAD_LEFT) ?></td>
          <td><?= esc($o['user_name']) ?></td>
          <td><?= esc($o['user_email']) ?></td>
          <td><?= rupiah($o['total']) ?></td>
          <td><?= esc($o['payment_method']) ?></td>
          <td><span class="status-pill status-<?= esc($o['status']) ?>"><?= esc($o['status']) ?></span></td>
          <td><?= date('d M Y', strtotime($o['created_at'])) ?></td>
          <td>
            <form method="post" style="display:flex; gap:6px;">
              <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
              <select name="status" style="padding:6px; border-radius:6px; border:1px solid var(--border-color); font-size:13px;">
                <?php foreach (['Diproses','Dikirim','Selesai','Dibatalkan'] as $s): ?>
                  <option value="<?= $s ?>" <?= $o['status']===$s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
              </select>
              <button type="submit" name="update_status" class="btn btn-sm btn-primary">Update</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require '../includes/admin_footer.php'; ?>
