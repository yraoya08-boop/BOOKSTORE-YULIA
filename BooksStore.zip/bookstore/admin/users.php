<?php
require_once '../config.php';
requireAdmin();
$pageTitle = 'Data User';

$users = $conn->query("SELECT u.*, (SELECT COUNT(*) FROM orders WHERE orders.user_id = u.id) AS order_count
                        FROM users u WHERE u.role = 'user' ORDER BY u.created_at DESC");

require '../includes/admin_header.php';
?>

<div class="card-box">
  <h3>User Terdaftar (<?= $users->num_rows ?>)</h3>
  <table class="data-table">
    <thead><tr><th>Nama</th><th>Email</th><th>No. Telepon</th><th>Total Pesanan</th><th>Terdaftar Sejak</th></tr></thead>
    <tbody>
      <?php if ($users->num_rows === 0): ?>
        <tr><td colspan="5">Belum ada user terdaftar.</td></tr>
      <?php endif; ?>
      <?php while ($u = $users->fetch_assoc()): ?>
        <tr>
          <td><?= esc($u['name']) ?></td>
          <td><?= esc($u['email']) ?></td>
          <td><?= esc($u['phone'] ?: '-') ?></td>
          <td><?= (int)$u['order_count'] ?></td>
          <td><?= date('d M Y', strtotime($u['created_at'])) ?></td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require '../includes/admin_footer.php'; ?>
