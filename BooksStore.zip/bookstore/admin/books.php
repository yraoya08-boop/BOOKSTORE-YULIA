<?php
require_once '../config.php';
requireAdmin();
$pageTitle = 'Data Buku';

$editData = null;

// ----- Delete -----
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM books WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    setFlash('success', 'Buku berhasil dihapus.');
    header('Location: books.php');
    exit;
}

// ----- Add / Update -----
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $title = trim($_POST['title'] ?? '');
    $author = trim($_POST['author'] ?? '');
    $category_id = (int)($_POST['category_id'] ?? 0) ?: null;
    $price = (float)($_POST['price'] ?? 0);
    $rating = (float)($_POST['rating'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $badge = $_POST['badge'] ?? '';
    $badge = $badge === '' ? null : $badge;
    $description = trim($_POST['description'] ?? '');

    if ($title === '' || $author === '') {
        setFlash('error', 'Judul dan penulis wajib diisi.');
        header('Location: books.php');
        exit;
    }

    // Upload cover jika ada file baru
    $coverName = $_POST['existing_cover'] ?? null;
    if (isset($_FILES['cover']) && $_FILES['cover']['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','webp'];
        if (in_array($ext, $allowed)) {
            $coverName = 'book_' . time() . '_' . rand(100,999) . '.' . $ext;
            move_uploaded_file($_FILES['cover']['tmp_name'], __DIR__ . '/../uploads/' . $coverName);
        }
    }

    if ($id > 0) {
        $stmt = $conn->prepare("UPDATE books SET title=?, author=?, category_id=?, price=?, rating=?, stock=?, cover_image=?, badge=?, description=? WHERE id=?");
        $stmt->bind_param('ssiddisssi', $title, $author, $category_id, $price, $rating, $stock, $coverName, $badge, $description, $id);
        $stmt->execute();
        setFlash('success', 'Buku berhasil diperbarui.');
    } else {
        $stmt = $conn->prepare("INSERT INTO books (title, author, category_id, price, rating, stock, cover_image, badge, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param('ssiddisss', $title, $author, $category_id, $price, $rating, $stock, $coverName, $badge, $description);
        $stmt->execute();
        setFlash('success', 'Buku berhasil ditambahkan.');
    }
    header('Location: books.php');
    exit;
}

if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->bind_param('i', $id);
    $stmt->execute();
    $editData = $stmt->get_result()->fetch_assoc();
}

$categories = $conn->query("SELECT * FROM categories ORDER BY name ASC");
$catList = [];
while ($c = $categories->fetch_assoc()) $catList[] = $c;

$books = $conn->query("SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id ORDER BY b.id DESC");

require '../includes/admin_header.php';
?>

<div class="card-box">
  <h3><?= $editData ? 'Edit Buku' : 'Tambah Buku Baru' ?></h3>
  <form method="post" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $editData['id'] ?? '' ?>">
    <input type="hidden" name="existing_cover" value="<?= esc($editData['cover_image'] ?? '') ?>">
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
      <div class="form-group">
        <label>Judul Buku</label>
        <input type="text" name="title" value="<?= esc($editData['title'] ?? '') ?>" required>
      </div>
      <div class="form-group">
        <label>Penulis</label>
        <input type="text" name="author" value="<?= esc($editData['author'] ?? '') ?>" required>
      </div>
    </div>
    <div style="display:grid; grid-template-columns: repeat(4, 1fr); gap:16px;">
      <div class="form-group">
        <label>Kategori</label>
        <select name="category_id">
          <option value="">- Pilih -</option>
          <?php foreach ($catList as $c): ?>
            <option value="<?= $c['id'] ?>" <?= (($editData['category_id'] ?? null) == $c['id']) ? 'selected' : '' ?>><?= esc($c['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group">
        <label>Harga (Rp)</label>
        <input type="number" step="0.01" name="price" value="<?= esc($editData['price'] ?? 0) ?>" required>
      </div>
      <div class="form-group">
        <label>Rating (0-5)</label>
        <input type="number" step="0.1" min="0" max="5" name="rating" value="<?= esc($editData['rating'] ?? 0) ?>">
      </div>
      <div class="form-group">
        <label>Stok</label>
        <input type="number" name="stock" value="<?= esc($editData['stock'] ?? 0) ?>">
      </div>
    </div>
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
      <div class="form-group">
        <label>Badge</label>
        <select name="badge">
          <option value="" <?= empty($editData['badge']) ? 'selected' : '' ?>>- Tidak ada -</option>
          <option value="Bestseller" <?= (($editData['badge'] ?? '') === 'Bestseller') ? 'selected' : '' ?>>Bestseller</option>
          <option value="Baru" <?= (($editData['badge'] ?? '') === 'Baru') ? 'selected' : '' ?>>Baru</option>
        </select>
      </div>
      <div class="form-group">
        <label>Cover Buku (jpg/png/webp)</label>
        <input type="file" name="cover" accept=".jpg,.jpeg,.png,.webp">
      </div>
    </div>
    <div class="form-group">
      <label>Deskripsi</label>
      <textarea name="description"><?= esc($editData['description'] ?? '') ?></textarea>
    </div>
    <button type="submit" class="btn btn-primary"><?= $editData ? 'Simpan Perubahan' : 'Tambah Buku' ?></button>
    <?php if ($editData): ?><a href="books.php" class="btn btn-outline" style="border-color:#d1d5db; color:#374151;">Batal</a><?php endif; ?>
  </form>
</div>

<div class="card-box">
  <h3>Daftar Buku</h3>
  <table class="data-table">
    <thead><tr><th>Cover</th><th>Judul</th><th>Penulis</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr></thead>
    <tbody>
      <?php while ($b = $books->fetch_assoc()): ?>
        <tr>
          <td><img src="<?= bookCover($b['cover_image'], $b['title']) ?>" alt=""></td>
          <td><?= esc($b['title']) ?><?php if ($b['badge']): ?> <span class="badge badge-<?= strtolower($b['badge'])==='baru'?'baru':'bestseller' ?>" style="font-size:9px;"><?= esc($b['badge']) ?></span><?php endif; ?></td>
          <td><?= esc($b['author']) ?></td>
          <td><?= esc($b['category_name'] ?? '-') ?></td>
          <td><?= rupiah($b['price']) ?></td>
          <td><?= (int)$b['stock'] ?></td>
          <td class="action-links">
            <a href="books.php?edit=<?= $b['id'] ?>" class="edit">Edit</a>
            <a href="books.php?delete=<?= $b['id'] ?>" class="delete confirm-delete" data-msg="Hapus buku ini?">Hapus</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </tbody>
  </table>
</div>

<?php require '../includes/admin_footer.php'; ?>
