-- =========================================================
-- NIJBOOK - BOOKSTORE DATABASE
-- Import file ini ke phpMyAdmin / MySQL sebelum menjalankan web
-- =========================================================

CREATE DATABASE IF NOT EXISTS nijbook_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nijbook_db;

-- Bersihkan tabel lama (jika ada) supaya import selalu mulai dari kondisi bersih & urut.
-- Urutan drop: tabel anak dulu, baru tabel induk (menghindari error foreign key).
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS books;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------
-- Tabel users (Admin & User digabung, dibedakan lewat kolom role)
-- ---------------------------------------------------------
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(30) DEFAULT NULL,
    address TEXT DEFAULT NULL,
    role ENUM('admin','user') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel categories
-- ---------------------------------------------------------
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(10) DEFAULT '📚',
    color VARCHAR(20) DEFAULT 'blue',
    description VARCHAR(255) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel books
-- ---------------------------------------------------------
CREATE TABLE books (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    author VARCHAR(150) NOT NULL,
    category_id INT DEFAULT NULL,
    price DECIMAL(12,2) NOT NULL DEFAULT 0,
    rating DECIMAL(2,1) NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT 0,
    cover_image VARCHAR(255) DEFAULT NULL,
    badge VARCHAR(20) DEFAULT NULL, -- Bestseller / Baru / NULL
    description TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel cart (keranjang belanja)
-- ---------------------------------------------------------
CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    book_id INT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel orders (pesanan - Payment at Delivery / COD)
-- ---------------------------------------------------------
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total DECIMAL(12,2) NOT NULL DEFAULT 0,
    payment_method VARCHAR(50) NOT NULL DEFAULT 'Payment at Delivery',
    shipping_address TEXT DEFAULT NULL,
    status ENUM('Diproses','Dikirim','Selesai','Dibatalkan') NOT NULL DEFAULT 'Diproses',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel order_items
-- ---------------------------------------------------------
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    book_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    price DECIMAL(12,2) NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (book_id) REFERENCES books(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- Tabel messages (Contact to Admin)
-- ---------------------------------------------------------
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    subject VARCHAR(200) DEFAULT NULL,
    message TEXT NOT NULL,
    is_read TINYINT(1) NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- =========================================================
-- SEED DATA
-- =========================================================

-- Password untuk kedua akun di bawah adalah: password123
-- (hash dibuat dengan password_hash('password123', PASSWORD_DEFAULT))
INSERT INTO users (name, email, password, role) VALUES
('Admin Nijbook', 'admin@nijbook.com', '$2b$12$N8nSUQde5jwufkMJQcCsgOOPY.lRH5zAJLn2tPgEA5FkCF1eBgwb6', 'admin'),
('Budi Santoso', 'budi@mail.com', '$2b$12$N8nSUQde5jwufkMJQcCsgOOPY.lRH5zAJLn2tPgEA5FkCF1eBgwb6', 'user');

INSERT INTO categories (name, icon, color, description) VALUES
('Teen & Young Adult Fiction', '📘', 'blue', 'Cerita fiksi untuk remaja dan dewasa muda'),
('Adult Fiction', '📈', 'yellow', 'Fiksi dewasa dengan cerita mendalam'),
('Motivation & Self-Help', '🌱', 'green', 'Buku pengembangan diri dan motivasi'),
('Business & Investing', '🧙', 'purple', 'Buku bisnis dan investasi'),
('Romance', '🙂', 'pink', 'Kisah cinta dan romansa');

-- Catatan: category_id dicari lewat subquery berdasarkan NAMA kategori (bukan angka hardcode),
-- supaya tetap aman walau id auto_increment kategori berbeda-beda di setiap instalasi.
INSERT INTO books (title, author, category_id, price, rating, stock, cover_image, badge, description) VALUES
('Atomic Habits', 'James Clear', (SELECT id FROM categories WHERE name = 'Motivation & Self-Help' LIMIT 1), 98000, 4.9, 50, NULL, 'Bestseller', 'Perubahan kecil yang memberikan hasil luar biasa. Cara mudah dan terbukti untuk membentuk kebiasaan baik dan menghilangkan kebiasaan buruk.'),
('Laut Bercerita', 'Leila S. Chudori', (SELECT id FROM categories WHERE name = 'Adult Fiction' LIMIT 1), 99000, 4.8, 30, NULL, 'Bestseller', 'Novel yang mengisahkan tentang perjuangan dan kehilangan di masa kelam sejarah Indonesia.'),
('Cantik Itu Luka', 'Eka Kurniawan', (SELECT id FROM categories WHERE name = 'Adult Fiction' LIMIT 1), 100000, 4.0, 25, NULL, 'Baru', 'Kisah magis realis tentang seorang wanita cantik bernama Dewi Ayu dan keempat anaknya.'),
('Seporsi Mie Ayam Sebelum Mati', 'Brian Khrisna', (SELECT id FROM categories WHERE name = 'Teen & Young Adult Fiction' LIMIT 1), 74000, 4.8, 40, NULL, NULL, 'Kumpulan cerita pendek yang menyentuh dan penuh makna kehidupan.'),
('Sisi Tergelap Surga', 'Brian Khrisna', (SELECT id FROM categories WHERE name = 'Adult Fiction' LIMIT 1), 79200, 4.8, 20, NULL, NULL, 'Novel dengan alur gelap dan penuh misteri tentang sisi tersembunyi kehidupan kota besar.'),
('Pulang', 'Leila S. Chudori', (SELECT id FROM categories WHERE name = 'Adult Fiction' LIMIT 1), 104000, 5.0, 15, NULL, NULL, 'Kisah keluarga eksil politik Indonesia yang tinggal di Paris.'),
('Yang Telah Lama Pergi', 'Tere Liye', (SELECT id FROM categories WHERE name = 'Teen & Young Adult Fiction' LIMIT 1), 94500, 4.9, 35, NULL, NULL, 'Novel keluarga yang mengharukan tentang kehilangan dan kenangan.'),
('Teka Teki Rumah Aneh', 'Uketsu', (SELECT id FROM categories WHERE name = 'Teen & Young Adult Fiction' LIMIT 1), 105825, 4.5, 28, NULL, NULL, 'Novel misteri populer dengan teka-teki seputar denah rumah yang aneh.'),
('Tentang Kamu', 'Tere Liye', (SELECT id FROM categories WHERE name = 'Romance' LIMIT 1), 98100, 5.0, 45, NULL, NULL, 'Kisah pencarian jati diri dan cinta yang menyentuh hati.');
