<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Checkout';
$uid = (int)$_SESSION['user_id'];

$buyNowId = isset($_GET['buy_now']) ? (int)$_GET['buy_now'] : (isset($_POST['buy_now']) ? (int)$_POST['buy_now'] : 0);

$rows = [];
$subtotal = 0;

if ($buyNowId > 0) {
    // Mode "Beli Sekarang" langsung dari halaman detail buku (tidak melalui cart)
    $stmt = $conn->prepare("SELECT * FROM books WHERE id = ?");
    $stmt->bind_param('i', $buyNowId);
    $stmt->execute();
    $b = $stmt->get_result()->fetch_assoc();
    if ($b) {
        $b['quantity'] = 1;
        $b['cart_id'] = null;
        $rows[] = $b;
        $subtotal = $b['price'];
    }
} else {
    // Mode checkout dari keranjang
    $stmt = $conn->prepare("SELECT cart.id AS cart_id, cart.quantity, books.* FROM cart
                             JOIN books ON cart.book_id = books.id
                             WHERE cart.user_id = ?");
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) {
        $rows[] = $row;
        $subtotal += $row['price'] * $row['quantity'];
    }
}

if (empty($rows)) {
    setFlash('info', 'Tidak ada buku untuk di-checkout.');
    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

$shipping = 15000;
$total = $subtotal + $shipping;

$errors = [];
$userStmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$userStmt->bind_param('i', $uid);
$userStmt->execute();
$currentUser = $userStmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    $address = trim($_POST['address'] ?? '');
    if ($address === '') {
        $errors[] = 'Alamat pengiriman wajib diisi.';
    }

    if (!$errors) {
        $conn->begin_transaction();
        try {
            $orderStmt = $conn->prepare("INSERT INTO orders (user_id, total, payment_method, shipping_address, status) VALUES (?, ?, 'Payment at Delivery', ?, 'Diproses')");
            $orderStmt->bind_param('ids', $uid, $total, $address);
            $orderStmt->execute();
            $orderId = $conn->insert_id;

            $itemStmt = $conn->prepare("INSERT INTO order_items (order_id, book_id, title, price, quantity) VALUES (?, ?, ?, ?, ?)");
            foreach ($rows as $r) {
                $itemStmt->bind_param('iisdi', $orderId, $r['id'], $r['title'], $r['price'], $r['quantity']);
                $itemStmt->execute();
            }

            if ($buyNowId === 0) {
                // hapus isi cart setelah checkout dari keranjang
                $del = $conn->prepare("DELETE FROM cart WHERE user_id = ?");
                $del->bind_param('i', $uid);
                $del->execute();
            }

            $conn->commit();
            setFlash('success', 'Pesanan berhasil dibuat! Pembayaran dilakukan saat buku diterima (COD).');
            header('Location: ' . BASE_URL . '/orders.php');
            exit;
        } catch (Exception $e) {
            $conn->rollback();
            $errors[] = 'Gagal membuat pesanan. Silakan coba lagi.';
        }
    }
}

require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / <a href="<?= BASE_URL ?>/cart.php">Keranjang</a> / Checkout</div>
  <h1>Checkout</h1>
</div>

<section class="section">
  <div class="container">
    <?php foreach ($errors as $err): ?>
      <div class="alert alert-error"><?= esc($err) ?></div>
    <?php endforeach; ?>

    <form method="post">
      <?php if ($buyNowId): ?><input type="hidden" name="buy_now" value="<?= $buyNowId ?>"><?php endif; ?>
      <div class="cart-layout">
        <div>
          <div class="card-box">
            <h3>Alamat Pengiriman</h3>
            <div class="form-group">
              <label>Nama Penerima</label>
              <input type="text" value="<?= esc($currentUser['name']) ?>" disabled>
            </div>
            <div class="form-group">
              <label>No. Telepon</label>
              <input type="text" value="<?= esc($currentUser['phone'] ?: '-') ?>" disabled>
            </div>
            <div class="form-group">
              <label>Alamat Lengkap</label>
              <textarea name="address" required placeholder="Masukkan alamat lengkap pengiriman..."><?= esc($currentUser['address'] ?? '') ?></textarea>
            </div>
          </div>

          <div class="card-box">
            <h3>Metode Pembayaran</h3>
            <div style="display:flex; align-items:center; gap:12px; padding:14px; border:1px solid var(--blue-600); border-radius:8px; background:var(--blue-50);">
              <span style="font-size:22px;">💵</span>
              <div>
                <strong>Payment at Delivery (COD)</strong>
                <p style="font-size:13px; color:var(--text-gray); margin-top:2px;">Bayar tunai saat buku sampai di alamatmu.</p>
              </div>
            </div>
          </div>

          <div class="card-box">
            <h3>Item Pesanan</h3>
            <?php foreach ($rows as $r): ?>
              <div style="display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border-color); font-size:14px;">
                <span><?= esc($r['title']) ?> &times; <?= $r['quantity'] ?></span>
                <strong><?= rupiah($r['price'] * $r['quantity']) ?></strong>
              </div>
            <?php endforeach; ?>
          </div>
        </div>

        <div class="summary-card">
          <h3>Ringkasan Pembayaran</h3>
          <div class="summary-row"><span>Subtotal</span><span><?= rupiah($subtotal) ?></span></div>
          <div class="summary-row"><span>Ongkos Kirim</span><span><?= rupiah($shipping) ?></span></div>
          <div class="summary-row total"><span>Total Bayar</span><span><?= rupiah($total) ?></span></div>
          <button type="submit" name="place_order" class="btn btn-primary btn-full" style="margin-top:10px;">Buat Pesanan (COD)</button>
        </div>
      </div>
    </form>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
