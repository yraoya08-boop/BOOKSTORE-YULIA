<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Profil Saya';
$uid = (int)$_SESSION['user_id'];

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');

    if ($name === '') {
        $errors[] = 'Nama tidak boleh kosong.';
    } else {
        $stmt = $conn->prepare("UPDATE users SET name = ?, phone = ?, address = ? WHERE id = ?");
        $stmt->bind_param('sssi', $name, $phone, $address, $uid);
        $stmt->execute();
        $_SESSION['user_name'] = $name;
        setFlash('success', 'Profil berhasil diperbarui.');
        header('Location: ' . BASE_URL . '/profile.php');
        exit;
    }
}

$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param('i', $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Profil Saya</div>
  <h1>Profil Saya</h1>
</div>

<section class="section">
  <div class="container" style="max-width:500px;">
    <?php foreach ($errors as $err): ?>
      <div class="alert alert-error"><?= esc($err) ?></div>
    <?php endforeach; ?>
    <div class="card-box">
      <form method="post">
        <div class="form-group">
          <label>Nama Lengkap</label>
          <input type="text" name="name" value="<?= esc($user['name']) ?>" required>
        </div>
        <div class="form-group">
          <label>Email</label>
          <input type="email" value="<?= esc($user['email']) ?>" disabled>
        </div>
        <div class="form-group">
          <label>No. Telepon</label>
          <input type="text" name="phone" value="<?= esc($user['phone']) ?>">
        </div>
        <div class="form-group">
          <label>Alamat</label>
          <textarea name="address"><?= esc($user['address']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Simpan Perubahan</button>
      </form>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
