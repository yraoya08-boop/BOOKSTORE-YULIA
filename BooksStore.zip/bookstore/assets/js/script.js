// =========================================================
// NIJBOOK - MAIN SCRIPT
// =========================================================

document.addEventListener('DOMContentLoaded', function () {

  // ---- Close promo bar ----
  const promoClose = document.querySelector('.promo-close');
  const promoBar = document.querySelector('.promo-bar');
  if (promoClose && promoBar) {
    promoClose.addEventListener('click', () => promoBar.style.display = 'none');
  }

  // ---- Mobile menu toggle ----
  const mobileToggle = document.querySelector('.mobile-toggle');
  const navLinks = document.querySelector('.nav-links');
  if (mobileToggle && navLinks) {
    mobileToggle.addEventListener('click', () => {
      navLinks.classList.toggle('mobile-open');
      navLinks.style.display = navLinks.classList.contains('mobile-open') ? 'flex' : 'none';
    });
  }

  // ---- Kategori tab filter (client side, dipakai di books.php) ----
  const tabButtons = document.querySelectorAll('.tab-btn');
  tabButtons.forEach(btn => {
    btn.addEventListener('click', function (e) {
      // Jika tombol punya href (server-side filter), biarkan browser navigasi biasa
      if (this.tagName === 'A') return;
      tabButtons.forEach(b => b.classList.remove('active'));
      this.classList.add('active');
    });
  });

  // ---- Quantity control di halaman cart ----
  document.querySelectorAll('.qty-control').forEach(control => {
    const minusBtn = control.querySelector('.qty-minus');
    const plusBtn = control.querySelector('.qty-plus');
    const input = control.querySelector('input[name="quantity"]');
    if (!input) return;

    if (minusBtn) {
      minusBtn.addEventListener('click', () => {
        let val = parseInt(input.value || '1', 10);
        if (val > 1) input.value = val - 1;
      });
    }
    if (plusBtn) {
      plusBtn.addEventListener('click', () => {
        let val = parseInt(input.value || '1', 10);
        const max = parseInt(input.getAttribute('max') || '99', 10);
        if (val < max) input.value = val + 1;
      });
    }
  });

  // ---- Konfirmasi sebelum hapus (dipakai di admin & cart) ----
  document.querySelectorAll('.confirm-delete').forEach(el => {
    el.addEventListener('click', function (e) {
      const msg = this.getAttribute('data-msg') || 'Yakin ingin menghapus data ini?';
      if (!confirm(msg)) {
        e.preventDefault();
      }
    });
  });

  // ---- Auto hide flash alert setelah beberapa detik ----
  const alertBox = document.querySelector('.alert');
  if (alertBox) {
    setTimeout(() => {
      alertBox.style.transition = 'opacity .4s ease';
      alertBox.style.opacity = '0';
      setTimeout(() => alertBox.remove(), 400);
    }, 3500);
  }

});
