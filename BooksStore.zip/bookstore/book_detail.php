<?php
require_once 'config.php';

$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT b.*, c.name AS category_name FROM books b LEFT JOIN categories c ON b.category_id = c.id WHERE b.id = ?");
$stmt->bind_param('i', $id);
$stmt->execute();
$book = $stmt->get_result()->fetch_assoc();

if (!$book) {
    header('Location: ' . BASE_URL . '/books.php');
    exit;
}
$pageTitle = $book['title'];

// ----- Handle Add to Cart -----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    if (!isLoggedIn()) {
        setFlash('info', 'Silakan login terlebih dahulu untuk menambahkan buku ke keranjang.');
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
    $qty = max(1, (int)($_POST['quantity'] ?? 1));
    $uid = (int)$_SESSION['user_id'];

    $check = $conn->prepare("SELECT id, quantity FROM cart WHERE user_id = ? AND book_id = ?");
    $check->bind_param('ii', $uid, $id);
    $check->execute();
    $existing = $check->get_result()->fetch_assoc();

    if ($existing) {
        $newQty = $existing['quantity'] + $qty;
        $upd = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ?");
        $upd->bind_param('ii', $newQty, $existing['id']);
        $upd->execute();
    } else {
        $ins = $conn->prepare("INSERT INTO cart (user_id, book_id, quantity) VALUES (?, ?, ?)");
        $ins->bind_param('iii', $uid, $id, $qty);
        $ins->execute();
    }
    setFlash('success', 'Buku berhasil ditambahkan ke keranjang.');
    header('Location: ' . BASE_URL . '/book_detail.php?id=' . $id);
    exit;
}

// Buku terkait (kategori sama)
$related = null;
if ($book['category_id']) {
    $r = $conn->prepare("SELECT * FROM books WHERE category_id = ? AND id != ? LIMIT 4");
    $r->bind_param('ii', $book['category_id'], $id);
    $r->execute();
    $related = $r->get_result();
}

require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / <a href="<?= BASE_URL ?>/books.php">Buku</a> / <?= esc($book['title']) ?></div>
</div>

<section class="section" style="padding-top:10px;">
  <div class="container" style="display:grid; grid-template-columns: 380px 1fr; gap:40px; align-items:start;">
    <div class="hero-card" style="max-width:100%; margin:0;">
      <?php if ($book['badge']): ?>
        <span class="badge badge-<?= strtolower($book['badge']) === 'baru' ? 'baru' : 'bestseller' ?>"><?= esc($book['badge']) ?></span>
      <?php endif; ?>
      <img src="<?= bookCover($book['cover_image'], $book['title']) ?>" alt="<?= esc($book['title']) ?>" style="margin-top:30px;">
    </div>

    <div>
      <?php if ($book['category_name']): ?><span class="badge" style="background:#dbeafe; color:#1e3a8a;"><?= esc($book['category_name']) ?></span><?php endif; ?>
      <h1 style="font-size:30px; font-weight:800; margin:14px 0 6px;"><?= esc($book['title']) ?></h1>
      <p style="color:var(--text-gray); font-size:15px; margin-bottom:12px;">oleh <strong><?= esc($book['author']) ?></strong></p>
      <div class="rating" style="font-size:16px; margin-bottom:16px;">★★★★★ <span class="count">(<?= number_format($book['rating'],1) ?>) &middot; Stok: <?= (int)$book['stock'] ?></span></div>
      <div class="price" style="font-size:32px; margin-bottom:20px;"><?= rupiah($book['price']) ?></div>
      <p style="color:#374151; line-height:1.8; margin-bottom:28px;"><?= nl2br(esc($book['description'] ?: 'Deskripsi belum tersedia untuk buku ini.')) ?></p>

      <form method="post" style="display:flex; gap:14px; align-items:center; flex-wrap:wrap;">
        <div class="qty-control" style="background:#f8fafc; padding:6px; border-radius:8px;">
          <button type="button" class="qty-minus">-</button>
          <input type="number" name="quantity" value="1" min="1" max="<?= (int)$book['stock'] ?>">
          <button type="button" class="qty-plus">+</button>
        </div>
        <button type="submit" name="add_to_cart" class="btn btn-outline" style="border-color:var(--blue-600); color:var(--blue-600);">🛍️ Add to Cart</button>
        <a href="<?= BASE_URL ?>/checkout.php?buy_now=<?= $book['id'] ?>" class="btn btn-primary">🛒 Beli Sekarang</a>
      </form>
    </div>
  </div>
</section>

<?php if ($related && $related->num_rows > 0): ?>
<section class="section" style="padding-top:0;">
  <div class="container">
    <div class="section-header"><h2>Buku Terkait</h2></div>
    <div class="book-grid">
      <?php while ($rb = $related->fetch_assoc()): ?>
        <div class="book-card">
          <div class="cover-wrap">
            <?php if ($rb['badge']): ?><span class="badge badge-<?= strtolower($rb['badge']) === 'baru' ? 'baru' : 'bestseller' ?>"><?= esc($rb['badge']) ?></span><?php endif; ?>
            <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $rb['id'] ?>"><img src="<?= bookCover($rb['cover_image'], $rb['title']) ?>" alt="<?= esc($rb['title']) ?>"></a>
          </div>
          <div class="book-body">
            <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $rb['id'] ?>"><h3><?= esc($rb['title']) ?></h3></a>
            <div class="author"><?= esc($rb['author']) ?></div>
            <div class="price-row"><span class="price"><?= rupiah($rb['price']) ?></span></div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<?php require 'includes/footer.php'; ?>
