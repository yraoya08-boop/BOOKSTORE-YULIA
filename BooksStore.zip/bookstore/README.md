# Nijbook - Website BookStore (PHP + MySQL)

Website toko buku online dengan 2 aktor: **Admin** dan **User** (digabung dalam satu tabel `users`,
dibedakan lewat kolom `role`). Desain mengikuti tampilan Nijbook yang diberikan (hero gelap, kartu buku,
promo bar, Remora Club, dsb).

## 🧩 Fitur

### User
- Registrasi & Login
- Melihat halaman About Us
- Contact to Admin (kirim pesan)
- Pencarian & filter buku per kategori
- Add to Cart (keranjang belanja)
- Checkout dengan **Payment at Delivery / COD**
- Riwayat pesanan & edit profil

### Admin
- Dashboard statistik
- CRUD Kategori Buku (Add/Update/Delete)
- CRUD Data Buku (Add/Update/Delete) + upload cover
- List User yang sudah terdaftar
- List & update status pesanan dari semua user
- Melihat pesan masuk dari fitur Contact to Admin

## ⚙️ Instalasi (XAMPP / Laragon)

1. **Copy folder project**
   Salin folder `bookstore` ini ke dalam `htdocs` (XAMPP) atau `www` (Laragon), sehingga path-nya:
   ```
   C:/xampp/htdocs/bookstore/
   ```

2. **Import database**
   - Buka phpMyAdmin (`http://localhost/phpmyadmin`)
   - Buat database baru bernama `nijbook_db`, atau langsung import file `database.sql`
     (file ini sudah membuat database + tabel + data contoh secara otomatis)

3. **Cek konfigurasi koneksi**
   Buka `config.php`, sesuaikan jika perlu:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'nijbook_db');
   define('BASE_URL', '/bookstore'); // sesuaikan dengan nama folder project Anda
   ```

4. **Beri izin folder upload**
   Pastikan folder `uploads/` bisa ditulis (untuk upload cover buku oleh admin).

5. **Jalankan**
   Buka browser ke:
   ```
   http://localhost/bookstore/index.php
   ```

## 🔑 Akun Demo

| Role  | Email               | Password    |
|-------|---------------------|-------------|
| Admin | admin@nijbook.com   | password123 |
| User  | budi@mail.com       | password123 |

## 🗂️ Struktur Folder

```
bookstore/
├── admin/                 # Halaman khusus admin (CRUD kategori, buku, user, pesanan, pesan)
├── assets/
│   ├── css/style.css      # Styling utama (mengikuti desain Nijbook)
│   └── js/script.js       # Interaksi UI (menu mobile, qty control, dsb)
├── includes/
│   ├── header.php / footer.php            # Layout halaman publik
│   └── admin_header.php / admin_footer.php # Layout halaman admin
├── uploads/               # Tempat penyimpanan cover buku hasil upload admin
├── config.php             # Koneksi database & fungsi helper
├── database.sql           # Skema database + data contoh
├── index.php               → Beranda
├── categories.php          → Semua kategori
├── books.php                → Daftar & pencarian buku
├── book_detail.php          → Detail buku + Add to Cart / Beli Sekarang
├── cart.php                 → Keranjang belanja
├── checkout.php             → Checkout (Payment at Delivery)
├── orders.php                → Riwayat pesanan user
├── profile.php               → Edit profil user
├── register.php / login.php / logout.php
├── about.php                 → About Us
├── contact.php               → Contact to Admin
├── membership.php            → Remora Club
└── newsletter.php            → Handler subscribe newsletter
```

## 📝 Catatan

- Password disimpan dengan `password_hash()` (bcrypt), diverifikasi dengan `password_verify()`.
- Semua query menggunakan **prepared statements** (mysqli) untuk mencegah SQL Injection.
- Jika ingin mengganti nama folder project, ubah nilai `BASE_URL` di `config.php`.
