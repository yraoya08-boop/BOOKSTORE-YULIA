<?php
require_once 'config.php';
$pageTitle = 'Kontak';

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $uid = isLoggedIn() ? (int)$_SESSION['user_id'] : null;

    if ($name === '' || $email === '' || $message === '') {
        $errors[] = 'Nama, email, dan pesan wajib diisi.';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Format email tidak valid.';
    }

    if (!$errors) {
        $stmt = $conn->prepare("INSERT INTO messages (user_id, name, email, subject, message) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param('issss', $uid, $name, $email, $subject, $message);
        $stmt->execute();
        $success = true;
    }
}

require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Kontak</div>
  <h1>Hubungi Kami</h1>
</div>

<section class="section">
  <div class="container" style="display:grid; grid-template-columns: 1fr 1.3fr; gap:30px;">
    <div class="card-box">
      <h3>Informasi Kontak</h3>
      <p style="margin-bottom:14px; color:#374151;"><strong>WhatsApp:</strong><br>+62 889-0504-7384</p>
      <p style="margin-bottom:14px; color:#374151;"><strong>Email:</strong><br>admin@nijbook.com</p>
      <p style="color:#374151;"><strong>Jam Operasional:</strong><br>Senin - Jumat, 09.00 - 18.00</p>
    </div>

    <div class="card-box">
      <h3>Kirim Pesan ke Admin</h3>
      <?php if ($success): ?>
        <div class="alert alert-success">Pesan kamu berhasil dikirim! Admin akan segera merespons.</div>
      <?php endif; ?>
      <?php foreach ($errors as $err): ?>
        <div class="alert alert-error"><?= esc($err) ?></div>
      <?php endforeach; ?>
      <form method="post">
        <div class="form-group">
          <label>Nama</label>
          <input type="text" name="name" value="<?= esc($_POST['name'] ?? ($_SESSION['user_name'] ?? '')) ?>" required>
        </div>
        <div class="form-group">
          <label>Email</label>
          <input type="email" name="email" value="<?= esc($_POST['email'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label>Subjek</label>
          <input type="text" name="subject" value="<?= esc($_POST['subject'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>Pesan</label>
          <textarea name="message" required placeholder="Tulis pesan kamu di sini..."><?= esc($_POST['message'] ?? '') ?></textarea>
        </div>
        <button type="submit" class="btn btn-primary btn-full">Kirim Pesan</button>
      </form>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
