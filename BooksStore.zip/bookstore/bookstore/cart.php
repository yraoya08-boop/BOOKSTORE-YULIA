<?php require 'config.php';require_user();$uid=$_SESSION['user']['id'];
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['update'])){foreach($_POST['qty'] as $id=>$q){$q=(int)$q;
    if($q<1)$pdo->prepare('DELETE FROM cart WHERE id=? AND user_id=?')->execute([$id,$uid]);
    else $pdo->prepare('UPDATE cart SET qty=? WHERE id=? AND user_id=?')->execute([$q,$id,$uid]);}flash('Keranjang diperbarui.');}
  if(isset($_POST['remove'])){$pdo->prepare('DELETE FROM cart WHERE id=? AND user_id=?')->execute([$_POST['remove'],$uid]);flash('Item dihapus.');}
  if(isset($_POST['checkout'])){ // Payment at Delivery
    $items=$pdo->prepare('SELECT c.qty,b.* FROM cart c JOIN books b ON b.id=c.book_id WHERE c.user_id=?');$items->execute([$uid]);$items=$items->fetchAll();
    $name=trim($_POST['name']);$phone=trim($_POST['phone']);$addr=trim($_POST['address']);
    if(!$items||!$name||!$phone||!$addr){flash('Lengkapi data pengiriman.');redirect('cart.php');}
    try{$pdo->beginTransaction();$total=0;
      foreach($items as $i){if($i['qty']>$i['stock'])throw new Exception('Stok "'.$i['title'].'" tidak cukup.');$total+=$i['qty']*$i['price'];}
      $pdo->prepare('INSERT INTO orders(user_id,name,phone,address,total) VALUES(?,?,?,?,?)')->execute([$uid,$name,$phone,$addr,$total]);$oid=$pdo->lastInsertId();
      foreach($items as $i){
        $pdo->prepare('INSERT INTO order_items(order_id,book_id,title,price,qty) VALUES(?,?,?,?,?)')->execute([$oid,$i['id'],$i['title'],$i['price'],$i['qty']]);
        $pdo->prepare('UPDATE books SET stock=stock-? WHERE id=?')->execute([$i['qty'],$i['id']]);}
      $pdo->prepare('DELETE FROM cart WHERE user_id=?')->execute([$uid]);$pdo->commit();
      flash('Pesanan berhasil dibuat. Metode: Payment at Delivery.');redirect('orders.php');
    }catch(Exception $x){$pdo->rollBack();flash($x->getMessage());redirect('cart.php');}}
  redirect('cart.php');}
$st=$pdo->prepare('SELECT c.id cid,c.qty,b.title,b.price FROM cart c JOIN books b ON b.id=c.book_id WHERE c.user_id=?');$st->execute([$uid]);$rows=$st->fetchAll();
$total=0;$title='Keranjang';require 'header.php'; ?>
<h2>Keranjang Belanja</h2>
<?php if(!$rows): ?><p>Keranjang kosong. <a href="index.php">Cari buku</a></p><?php else: ?>
<form method="post"><div class="tw"><table><tr><th>Buku</th><th>Harga</th><th>Qty</th><th>Subtotal</th><th></th></tr>
<?php foreach($rows as $r): $sub=$r['qty']*$r['price'];$total+=$sub; ?>
<tr><td><?=e($r['title'])?></td><td><?=rupiah($r['price'])?></td><td><input type="number" min="0" name="qty[<?=$r['cid']?>]" value="<?=$r['qty']?>" style="width:70px"></td><td><?=rupiah($sub)?></td>
<td><button class="btn sm red" name="remove" value="<?=$r['cid']?>">Hapus</button></td></tr><?php endforeach; ?>
<tr><th colspan="3">Total</th><th colspan="2"><?=rupiah($total)?></th></tr></table></div><br><button class="btn gray" name="update" value="1">Update Qty</button></form>
<h3>Data Pengiriman &amp; Pembayaran</h3>
<form class="box" method="post" style="margin:0"><label>Nama Penerima</label><input name="name" value="<?=e($_SESSION['user']['name'])?>" required>
<label>No. HP</label><input name="phone" required><label>Alamat Lengkap</label><textarea name="address" rows="3" required></textarea>
<label>Metode Pembayaran</label><input value="Payment at Delivery" disabled><br><br><button class="btn" name="checkout" value="1">Pesan Sekarang</button></form>
<?php endif; require 'footer.php'; ?>
