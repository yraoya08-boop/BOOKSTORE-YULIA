CREATE DATABASE IF NOT EXISTS bookstore CHARACTER SET utf8mb4;
USE bookstore;
CREATE TABLE users(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(100) NOT NULL UNIQUE,password VARCHAR(255) NOT NULL,role ENUM('admin','user') NOT NULL DEFAULT 'user',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE categories(id INT AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL);
CREATE TABLE books(id INT AUTO_INCREMENT PRIMARY KEY,category_id INT NULL,title VARCHAR(200) NOT NULL,author VARCHAR(100) NOT NULL,price INT NOT NULL,stock INT NOT NULL DEFAULT 0,description TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE SET NULL);
CREATE TABLE cart(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,book_id INT NOT NULL,qty INT NOT NULL DEFAULT 1,UNIQUE(user_id,book_id),FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,FOREIGN KEY(book_id) REFERENCES books(id) ON DELETE CASCADE);
CREATE TABLE orders(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,name VARCHAR(100) NOT NULL,phone VARCHAR(20) NOT NULL,address TEXT NOT NULL,total INT NOT NULL,payment_method VARCHAR(50) DEFAULT 'Payment at Delivery',status ENUM('Pending','Dikirim','Selesai') DEFAULT 'Pending',created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
CREATE TABLE order_items(id INT AUTO_INCREMENT PRIMARY KEY,order_id INT NOT NULL,book_id INT NULL,title VARCHAR(200),price INT,qty INT,FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE);
CREATE TABLE messages(id INT AUTO_INCREMENT PRIMARY KEY,user_id INT NOT NULL,subject VARCHAR(150) NOT NULL,message TEXT NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
-- Admin default: admin@bookstore.com / password
INSERT INTO users(name,email,password,role) VALUES('Administrator','admin@bookstore.com','$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi','admin');
INSERT INTO categories(name) VALUES('Novel'),('Teknologi'),('Pendidikan');
INSERT INTO books(category_id,title,author,price,stock,description) VALUES
(1,'Laskar Pelangi','Andrea Hirata',85000,20,'Kisah anak-anak Belitung yang berjuang meraih pendidikan.'),
(2,'Clean Code','Robert C. Martin',250000,10,'Panduan menulis kode yang bersih dan mudah dirawat.'),
(3,'Atomic Habits','James Clear',110000,15,'Cara membangun kebiasaan baik dan menghilangkan kebiasaan buruk.');
