<?php require '../config.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['delete'])){$pdo->prepare('DELETE FROM categories WHERE id=?')->execute([$_POST['delete']]);flash('Kategori dihapus.');}
  elseif(trim($_POST['name'])){
    if(!empty($_POST['id'])){$pdo->prepare('UPDATE categories SET name=? WHERE id=?')->execute([trim($_POST['name']),$_POST['id']]);flash('Kategori diperbarui.');}
    else{$pdo->prepare('INSERT INTO categories(name) VALUES(?)')->execute([trim($_POST['name'])]);flash('Kategori ditambahkan.');}}
  redirect('categories.php');}
$edit=null;if(isset($_GET['edit'])){$e=$pdo->prepare('SELECT * FROM categories WHERE id=?');$e->execute([$_GET['edit']]);$edit=$e->fetch();}
$cs=$pdo->query('SELECT * FROM categories ORDER BY id')->fetchAll();$title='Kategori';require '../header.php'; ?>
<h2>Kategori Buku</h2>
<form class="box" method="post" style="margin:0 0 20px"><input type="hidden" name="id" value="<?=e($edit['id']??'')?>"><label><?=$edit?'Edit':'Tambah'?> Kategori</label>
<input name="name" value="<?=e($edit['name']??'')?>" required><br><br><button class="btn"><?=$edit?'Update':'Add'?></button> <?php if($edit) echo '<a class="btn gray" href="categories.php">Batal</a>'; ?></form>
<table><tr><th>ID</th><th>Nama</th><th>Aksi</th></tr>
<?php foreach($cs as $c): ?><tr><td><?=$c['id']?></td><td><?=e($c['name'])?></td><td><a class="btn sm" href="?edit=<?=$c['id']?>">Edit</a>
<form class="inline" method="post" data-confirm="Hapus kategori ini?"><button class="btn sm red" name="delete" value="<?=$c['id']?>">Delete</button></form></td></tr><?php endforeach; ?></table>
<?php require '../footer.php'; ?>
