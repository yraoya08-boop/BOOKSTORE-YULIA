<?php require '../config.php';require_admin();
$us=$pdo->query("SELECT * FROM users WHERE role='user' ORDER BY id DESC")->fetchAll();$title='List User';require '../header.php'; ?>
<h2>User Terdaftar</h2><div class="tw"><table><tr><th>ID</th><th>Nama</th><th>Email</th><th>Terdaftar</th></tr>
<?php foreach($us as $u) echo '<tr><td>'.$u['id'].'</td><td>'.e($u['name']).'</td><td>'.e($u['email']).'</td><td>'.e($u['created_at']).'</td></tr>'; ?></table></div>
<?php require '../footer.php'; ?>
