<?php require '../config.php';require_admin();
$ms=$pdo->query('SELECT m.*,u.name,u.email FROM messages m JOIN users u ON u.id=m.user_id ORDER BY m.id DESC')->fetchAll();$title='Pesan Masuk';require '../header.php'; ?>
<h2>Pesan dari User</h2>
<?php foreach($ms as $m): ?><div class="card" style="margin-bottom:12px"><b><?=e($m['subject'])?></b><div class="muted"><?=e($m['name'])?> (<?=e($m['email'])?>) • <?=e($m['created_at'])?></div><p><?=nl2br(e($m['message']))?></p></div>
<?php endforeach; if(!$ms) echo '<p>Belum ada pesan.</p>'; require '../footer.php'; ?>
