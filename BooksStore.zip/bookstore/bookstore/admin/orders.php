<?php require '../config.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'&&in_array($_POST['status'],['Pending','Dikirim','Selesai'])){
  $pdo->prepare('UPDATE orders SET status=? WHERE id=?')->execute([$_POST['status'],$_POST['id']]);flash('Status pesanan diperbarui.');redirect('orders.php');}
$os=$pdo->query('SELECT o.*,u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC')->fetchAll();$title='Pesanan';require '../header.php'; ?>
<h2>Pesanan dari User</h2>
<?php foreach($os as $o): $it=$pdo->prepare('SELECT * FROM order_items WHERE order_id=?');$it->execute([$o['id']]); ?>
<div class="card" style="margin-bottom:14px"><b>Order #<?=$o['id']?></b> — <?=e($o['name'])?> (<?=e($o['email'])?>) • <?=e($o['phone'])?> <span class="muted"><?=e($o['created_at'])?></span>
<ul><?php foreach($it as $i) echo '<li>'.e($i['title']).' × '.$i['qty'].'</li>'; ?></ul>
<div class="muted">Alamat: <?=e($o['address'])?></div><div>Total: <span class="price"><?=rupiah($o['total'])?></span> • <?=e($o['payment_method'])?></div>
<form method="post" style="margin-top:8px"><input type="hidden" name="id" value="<?=$o['id']?>"><select name="status" style="width:auto">
<?php foreach(['Pending','Dikirim','Selesai'] as $s) echo '<option '.($o['status']===$s?'selected':'').'>'.$s.'</option>'; ?></select> <button class="btn sm">Update Status</button></form></div>
<?php endforeach; if(!$os) echo '<p>Belum ada pesanan.</p>'; require '../footer.php'; ?>
