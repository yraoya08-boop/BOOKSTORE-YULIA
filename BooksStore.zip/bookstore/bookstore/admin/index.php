<?php require '../config.php';require_admin();
$s=fn($t)=>$pdo->query("SELECT COUNT(*) FROM $t")->fetchColumn();
$title='Dashboard Admin';require '../header.php'; ?>
<h2>Dashboard Admin</h2><div class="stats">
<div class="card"><b><?=$s('books')?></b>Buku</div><div class="card"><b><?=$s('categories')?></b>Kategori</div>
<div class="card"><b><?=$pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn()?></b>User</div>
<div class="card"><b><?=$s('orders')?></b>Pesanan</div><div class="card"><b><?=$s('messages')?></b>Pesan Masuk</div></div>
<?php require '../footer.php'; ?>
