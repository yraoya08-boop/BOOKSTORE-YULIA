<?php require '../config.php';require_admin();
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(isset($_POST['delete'])){$pdo->prepare('DELETE FROM books WHERE id=?')->execute([$_POST['delete']]);flash('Buku dihapus.');}
  else{$d=[$_POST['category_id']?:null,trim($_POST['title']),trim($_POST['author']),max(0,(int)$_POST['price']),max(0,(int)$_POST['stock']),trim($_POST['description'])];
    if(!empty($_POST['id'])){$d[]=$_POST['id'];$pdo->prepare('UPDATE books SET category_id=?,title=?,author=?,price=?,stock=?,description=? WHERE id=?')->execute($d);flash('Buku diperbarui.');}
    else{$pdo->prepare('INSERT INTO books(category_id,title,author,price,stock,description) VALUES(?,?,?,?,?,?)')->execute($d);flash('Buku ditambahkan.');}}
  redirect('books.php');}
$edit=null;if(isset($_GET['edit'])){$e=$pdo->prepare('SELECT * FROM books WHERE id=?');$e->execute([$_GET['edit']]);$edit=$e->fetch();}
$cats=$pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$bs=$pdo->query('SELECT b.*,c.name cname FROM books b LEFT JOIN categories c ON c.id=b.category_id ORDER BY b.id DESC')->fetchAll();
$title='Data Buku';require '../header.php'; ?>
<h2>Data Buku</h2>
<form class="box" method="post" style="margin:0 0 20px;max-width:600px"><input type="hidden" name="id" value="<?=e($edit['id']??'')?>"><h3><?=$edit?'Edit':'Tambah'?> Buku</h3>
<label>Judul</label><input name="title" value="<?=e($edit['title']??'')?>" required><label>Penulis</label><input name="author" value="<?=e($edit['author']??'')?>" required>
<label>Kategori</label><select name="category_id"><option value="">- Tanpa kategori -</option><?php foreach($cats as $c): ?><option value="<?=$c['id']?>" <?=($edit['category_id']??0)==$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach; ?></select>
<label>Harga (Rp)</label><input type="number" name="price" min="0" value="<?=e($edit['price']??'')?>" required><label>Stok</label><input type="number" name="stock" min="0" value="<?=e($edit['stock']??'')?>" required>
<label>Deskripsi</label><textarea name="description" rows="3"><?=e($edit['description']??'')?></textarea><br><br><button class="btn"><?=$edit?'Update':'Add'?></button> <?php if($edit) echo '<a class="btn gray" href="books.php">Batal</a>'; ?></form>
<div class="tw"><table><tr><th>ID</th><th>Judul</th><th>Penulis</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th></tr>
<?php foreach($bs as $b): ?><tr><td><?=$b['id']?></td><td><?=e($b['title'])?></td><td><?=e($b['author'])?></td><td><?=e($b['cname']??'-')?></td><td><?=rupiah($b['price'])?></td><td><?=$b['stock']?></td>
<td><a class="btn sm" href="?edit=<?=$b['id']?>">Edit</a> <form class="inline" method="post" data-confirm="Hapus buku ini?"><button class="btn sm red" name="delete" value="<?=$b['id']?>">Delete</button></form></td></tr><?php endforeach; ?></table></div>
<?php require '../footer.php'; ?>
