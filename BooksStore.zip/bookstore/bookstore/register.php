<?php require 'config.php';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $n=trim($_POST['name']);$em=trim($_POST['email']);$pw=$_POST['password'];
  if(!$n||!filter_var($em,FILTER_VALIDATE_EMAIL)||strlen($pw)<6)$err='Data tidak valid (password minimal 6 karakter).';
  else{$c=$pdo->prepare('SELECT id FROM users WHERE email=?');$c->execute([$em]);
    if($c->fetch())$err='Email sudah terdaftar.';
    else{$pdo->prepare("INSERT INTO users(name,email,password,role) VALUES(?,?,?,'user')")->execute([$n,$em,password_hash($pw,PASSWORD_DEFAULT)]);flash('Registrasi berhasil, silakan login.');redirect('login.php');}}}
$title='Registrasi';require 'header.php'; ?>
<form class="box" id="regForm" method="post"><h2>Registrasi User</h2><?php if($err) echo '<div class="alert err">'.e($err).'</div>'; ?>
<label>Nama</label><input name="name" required><label>Email</label><input type="email" name="email" required>
<label>Password</label><input type="password" name="password" required><label>Konfirmasi Password</label><input type="password" name="confirm" required>
<br><br><button class="btn">Daftar</button> <a href="login.php">Sudah punya akun?</a></form><?php require 'footer.php'; ?>
