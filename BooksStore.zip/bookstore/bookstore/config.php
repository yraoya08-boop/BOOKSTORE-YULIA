<?php
session_start();
define('BASE','/bookstore/'); // sesuaikan dengan nama folder di htdocs
try{
  $pdo=new PDO('mysql:host=localhost;dbname=bookstore;charset=utf8mb4','root','',[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
}catch(PDOException $x){die('Koneksi database gagal. Pastikan MySQL aktif dan database.sql sudah di-import.');}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function rupiah($n){return 'Rp '.number_format((int)$n,0,',','.');}
function flash($m){$_SESSION['flash']=$m;}
function redirect($p){header('Location: '.$p);exit;}
function require_login(){if(empty($_SESSION['user']))redirect(BASE.'login.php');}
function require_admin(){require_login();if($_SESSION['user']['role']!=='admin'){http_response_code(403);exit('Akses ditolak.');}}
function require_user(){require_login();if($_SESSION['user']['role']!=='user')redirect(BASE.'admin/index.php');}
