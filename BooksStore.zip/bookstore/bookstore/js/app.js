document.querySelectorAll('form[data-confirm]').forEach(f=>f.addEventListener('submit',ev=>{if(!confirm(f.dataset.confirm))ev.preventDefault();}));
const rf=document.getElementById('regForm');
if(rf){rf.addEventListener('submit',ev=>{const p=rf.password.value,c=rf.confirm.value;
 if(p.length<6){alert('Password minimal 6 karakter.');ev.preventDefault();}
 else if(p!==c){alert('Konfirmasi password tidak sama.');ev.preventDefault();}});}
