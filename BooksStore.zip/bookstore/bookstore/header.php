<?php $u=$_SESSION['user']??null;$isAdmin=$u&&$u['role']==='admin'; ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($title??'BookStore')?> - BookStore</title><link rel="stylesheet" href="<?=BASE?>css/style.css"></head><body>
<header><div class="wrap nav"><a class="logo" href="<?=BASE?>index.php">📚 BookStore</a><nav>
<?php if($isAdmin): ?>
<a href="<?=BASE?>admin/index.php">Dashboard</a><a href="<?=BASE?>admin/categories.php">Kategori</a><a href="<?=BASE?>admin/books.php">Buku</a><a href="<?=BASE?>admin/users.php">User</a><a href="<?=BASE?>admin/orders.php">Pesanan</a><a href="<?=BASE?>admin/messages.php">Pesan</a>
<?php else: ?>
<a href="<?=BASE?>index.php">Beranda</a><a href="<?=BASE?>about.php">About Us</a>
<?php if($u): ?><a href="<?=BASE?>contact.php">Contact Admin</a><a href="<?=BASE?>cart.php">Keranjang</a><a href="<?=BASE?>orders.php">Pesanan Saya</a><?php endif; endif; ?>
<?php if($u): ?><a href="<?=BASE?>logout.php" class="btn sm">Logout (<?=e($u['name'])?>)</a>
<?php else: ?><a href="<?=BASE?>login.php">Login</a><a href="<?=BASE?>register.php" class="btn sm">Register</a><?php endif; ?>
</nav></div></header><main class="wrap">
<?php if(!empty($_SESSION['flash'])){echo '<div class="alert">'.e($_SESSION['flash']).'</div>';unset($_SESSION['flash']);} ?>
