<?php require 'config.php';require_user();
if($_SERVER['REQUEST_METHOD']==='POST'){
  $s=trim($_POST['subject']);$m=trim($_POST['message']);
  if($s&&$m){$pdo->prepare('INSERT INTO messages(user_id,subject,message) VALUES(?,?,?)')->execute([$_SESSION['user']['id'],$s,$m]);flash('Pesan terkirim ke admin.');redirect('contact.php');}}
$title='Contact Admin';require 'header.php'; ?>
<form class="box" method="post"><h2>Contact to Admin</h2><label>Subjek</label><input name="subject" required>
<label>Pesan</label><textarea name="message" rows="5" required></textarea><br><br><button class="btn">Kirim Pesan</button></form><?php require 'footer.php'; ?>
