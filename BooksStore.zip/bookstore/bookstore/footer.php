</main><footer><div class="wrap">© <?=date('Y')?> BookStore. All rights reserved.</div></footer><script src="<?=BASE?>js/app.js"></script></body></html>
