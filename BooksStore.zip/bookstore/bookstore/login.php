<?php require 'config.php';$err='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $st=$pdo->prepare('SELECT * FROM users WHERE email=?');$st->execute([trim($_POST['email'])]);$u=$st->fetch();
  if($u&&password_verify($_POST['password'],$u['password'])){
    session_regenerate_id(true);$_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'role'=>$u['role']];
    redirect($u['role']==='admin'?'admin/index.php':'index.php');
  }else $err='Email atau password salah.';}
$title='Login';require 'header.php'; ?>
<form class="box" method="post"><h2>Login</h2><?php if($err) echo '<div class="alert err">'.e($err).'</div>'; ?>
<label>Email</label><input type="email" name="email" required><label>Password</label><input type="password" name="password" required>
<br><br><button class="btn">Login</button> <a href="register.php">Belum punya akun?</a></form><?php require 'footer.php'; ?>
