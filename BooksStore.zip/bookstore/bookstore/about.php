<?php require 'config.php';$title='About Us';require 'header.php'; ?>
<div class="card"><h2>Tentang BookStore</h2>
<p>BookStore adalah toko buku online yang menyediakan berbagai buku berkualitas dari novel, teknologi, hingga pendidikan dengan harga terjangkau.</p>
<p><b>Visi:</b> Menjadikan membaca sebagai kebiasaan yang mudah dan menyenangkan.</p>
<p><b>Misi:</b> Menyediakan koleksi buku lengkap, layanan cepat, dan pembayaran yang aman (Payment at Delivery).</p>
<p class="muted">Email: admin@bookstore.com</p></div><?php require 'footer.php'; ?>
