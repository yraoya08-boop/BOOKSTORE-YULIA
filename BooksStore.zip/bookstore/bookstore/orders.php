<?php require 'config.php';require_user();
$st=$pdo->prepare('SELECT * FROM orders WHERE user_id=? ORDER BY id DESC');$st->execute([$_SESSION['user']['id']]);$os=$st->fetchAll();
$title='Pesanan Saya';require 'header.php'; ?>
<h2>Pesanan Saya</h2>
<?php foreach($os as $o): $it=$pdo->prepare('SELECT * FROM order_items WHERE order_id=?');$it->execute([$o['id']]); ?>
<div class="card" style="margin-bottom:14px"><b>Order #<?=$o['id']?></b> <span class="badge"><?=e($o['status'])?></span> <span class="muted"><?=e($o['created_at'])?></span>
<ul><?php foreach($it as $i) echo '<li>'.e($i['title']).' × '.$i['qty'].' ('.rupiah($i['price']).')</li>'; ?></ul>
<div>Total: <span class="price"><?=rupiah($o['total'])?></span> • <?=e($o['payment_method'])?></div><div class="muted">Kirim ke: <?=e($o['name'])?>, <?=e($o['address'])?></div></div>
<?php endforeach; if(!$os) echo '<p>Belum ada pesanan.</p>'; require 'footer.php'; ?>
