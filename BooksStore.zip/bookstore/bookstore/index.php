<?php require 'config.php';
if($_SERVER['REQUEST_METHOD']==='POST'&&isset($_POST['add'])){ // Add to Cart
  require_user();
  $pdo->prepare('INSERT INTO cart(user_id,book_id,qty) VALUES(?,?,1) ON DUPLICATE KEY UPDATE qty=qty+1')->execute([$_SESSION['user']['id'],(int)$_POST['add']]);
  flash('Buku ditambahkan ke keranjang.');redirect('index.php');
}
$q=trim($_GET['q']??'');$cat=(int)($_GET['cat']??0);
$sql='SELECT b.*,c.name cname FROM books b LEFT JOIN categories c ON c.id=b.category_id WHERE (b.title LIKE ? OR b.author LIKE ?)';
$p=["%$q%","%$q%"];if($cat){$sql.=' AND b.category_id=?';$p[]=$cat;}
$st=$pdo->prepare($sql.' ORDER BY b.id DESC');$st->execute($p);$books=$st->fetchAll();
$cats=$pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$title='Beranda';require 'header.php'; ?>
<h2>Cari Buku</h2>
<form class="search" method="get"><input name="q" placeholder="Judul atau penulis..." value="<?=e($q)?>">
<select name="cat"><option value="0">Semua Kategori</option><?php foreach($cats as $c): ?><option value="<?=$c['id']?>" <?=$cat==$c['id']?'selected':''?>><?=e($c['name'])?></option><?php endforeach; ?></select>
<button class="btn">Cari</button></form>
<div class="grid">
<?php foreach($books as $b): ?>
<div class="card"><div class="cover">📖</div><h3><?=e($b['title'])?></h3><div class="muted"><?=e($b['author'])?> • <span class="badge"><?=e($b['cname']??'-')?></span></div>
<p><?=e(mb_strimwidth($b['description'],0,90,'...'))?></p><div class="price"><?=rupiah($b['price'])?></div><div class="muted">Stok: <?=$b['stock']?></div>
<?php if(!(isset($_SESSION['user'])&&$_SESSION['user']['role']==='admin')): ?>
<form method="post"><?php if($b['stock']>0): ?><button class="btn" name="add" value="<?=$b['id']?>">+ Add to Cart</button><?php else: ?><span class="muted">Stok habis</span><?php endif; ?></form>
<?php endif; ?></div>
<?php endforeach; if(!$books) echo '<p>Buku tidak ditemukan.</p>'; ?>
</div><?php require 'footer.php'; ?>
