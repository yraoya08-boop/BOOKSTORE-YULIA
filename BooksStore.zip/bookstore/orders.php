<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Pesanan Saya';
$uid = (int)$_SESSION['user_id'];

$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC");
$stmt->bind_param('i', $uid);
$stmt->execute();
$orders = $stmt->get_result();

require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Pesanan Saya</div>
  <h1>Pesanan Saya</h1>
</div>

<section class="section">
  <div class="container">
    <?php if ($orders->num_rows === 0): ?>
      <div class="empty-state">
        <div class="icon">📦</div>
        <p>Kamu belum memiliki pesanan.</p>
        <a href="<?= BASE_URL ?>/books.php" class="btn btn-primary" style="margin-top:16px;">Mulai Belanja</a>
      </div>
    <?php else: ?>
      <?php while ($o = $orders->fetch_assoc()):
        $itemsStmt = $conn->prepare("SELECT * FROM order_items WHERE order_id = ?");
        $itemsStmt->bind_param('i', $o['id']);
        $itemsStmt->execute();
        $items = $itemsStmt->get_result();
      ?>
        <div class="card-box">
          <div style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:10px; margin-bottom:14px;">
            <div>
              <strong>Order #<?= str_pad($o['id'], 5, '0', STR_PAD_LEFT) ?></strong>
              <div style="font-size:13px; color:var(--text-gray);"><?= date('d M Y, H:i', strtotime($o['created_at'])) ?></div>
            </div>
            <span class="status-pill status-<?= esc($o['status']) ?>"><?= esc($o['status']) ?></span>
          </div>
          <?php while ($it = $items->fetch_assoc()): ?>
            <div style="display:flex; justify-content:space-between; padding:8px 0; border-bottom:1px solid var(--border-color); font-size:14px;">
              <span><?= esc($it['title']) ?> &times; <?= $it['quantity'] ?></span>
              <span><?= rupiah($it['price'] * $it['quantity']) ?></span>
            </div>
          <?php endwhile; ?>
          <div style="display:flex; justify-content:space-between; padding-top:14px; font-weight:800;">
            <span>Total (COD)</span>
            <span><?= rupiah($o['total']) ?></span>
          </div>
        </div>
      <?php endwhile; ?>
    <?php endif; ?>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
