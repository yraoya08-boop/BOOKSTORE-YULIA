<?php
require_once 'config.php';
$pageTitle = 'Login';

if (isLoggedIn()) {
    header('Location: ' . (isAdmin() ? BASE_URL . '/admin/index.php' : BASE_URL . '/index.php'));
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'Email dan password wajib diisi.';
    } else {
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['role'] = $user['role'];

            if ($user['role'] === 'admin') {
                header('Location: ' . BASE_URL . '/admin/index.php');
            } else {
                header('Location: ' . BASE_URL . '/index.php');
            }
            exit;
        } else {
            $errors[] = 'Email atau password salah.';
        }
    }
}

require 'includes/header.php';
?>

<div class="auth-wrap">
  <div class="auth-card">
    <h2>Selamat Datang Kembali</h2>
    <p class="sub">Login untuk melanjutkan belanja buku favoritmu</p>

    <?php foreach ($errors as $err): ?>
      <div class="alert alert-error"><?= esc($err) ?></div>
    <?php endforeach; ?>

    <form method="post">
      <div class="form-group">
        <label>Email</label>
        <input type="email" name="email" value="<?= esc($_POST['email'] ?? '') ?>" required autofocus>
      </div>
      <div class="form-group">
        <label>Password</label>
        <input type="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-full">Login</button>
    </form>
    <div class="auth-foot">Belum punya akun? <a href="<?= BASE_URL ?>/register.php">Daftar di sini</a></div>
    <p style="text-align:center; font-size:12px; color:#9ca3af; margin-top:16px;">
      Demo Admin: admin@nijbook.com / password123<br>
      Demo User: budi@mail.com / password123
    </p>
  </div>
</div>

<?php require 'includes/footer.php'; ?>
