<?php
require_once 'config.php';
requireLogin();
$pageTitle = 'Keranjang';
$uid = (int)$_SESSION['user_id'];

// ----- Update quantity -----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_cart'])) {
    $cartId = (int)$_POST['cart_id'];
    $qty = max(1, (int)$_POST['quantity']);
    $stmt = $conn->prepare("UPDATE cart SET quantity = ? WHERE id = ? AND user_id = ?");
    $stmt->bind_param('iii', $qty, $cartId, $uid);
    $stmt->execute();
    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

// ----- Remove item -----
if (isset($_GET['remove'])) {
    $cartId = (int)$_GET['remove'];
    $stmt = $conn->prepare("DELETE FROM cart WHERE id = ? AND user_id = ?");
    $stmt->bind_param('ii', $cartId, $uid);
    $stmt->execute();
    setFlash('success', 'Item dihapus dari keranjang.');
    header('Location: ' . BASE_URL . '/cart.php');
    exit;
}

$stmt = $conn->prepare("SELECT cart.id AS cart_id, cart.quantity, books.* FROM cart
                         JOIN books ON cart.book_id = books.id
                         WHERE cart.user_id = ? ORDER BY cart.created_at DESC");
$stmt->bind_param('i', $uid);
$stmt->execute();
$items = $stmt->get_result();

$subtotal = 0;
$rows = [];
while ($row = $items->fetch_assoc()) {
    $rows[] = $row;
    $subtotal += $row['price'] * $row['quantity'];
}
$shipping = $subtotal > 0 ? 15000 : 0;
$total = $subtotal + $shipping;

require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Keranjang</div>
  <h1>Keranjang Belanja</h1>
</div>

<section class="section">
  <div class="container">
    <?php if (empty($rows)): ?>
      <div class="empty-state">
        <div class="icon">🛍️</div>
        <p>Keranjang kamu masih kosong.</p>
        <a href="<?= BASE_URL ?>/books.php" class="btn btn-primary" style="margin-top:16px;">Jelajahi Buku</a>
      </div>
    <?php else: ?>
      <div class="cart-layout">
        <div>
          <?php foreach ($rows as $r): ?>
            <div class="cart-item">
              <img src="<?= bookCover($r['cover_image'], $r['title']) ?>" alt="<?= esc($r['title']) ?>">
              <div>
                <h4><?= esc($r['title']) ?></h4>
                <div class="author"><?= esc($r['author']) ?></div>
                <div class="price" style="margin-top:6px;"><?= rupiah($r['price']) ?></div>
              </div>
              <form method="post" class="qty-control">
                <input type="hidden" name="cart_id" value="<?= $r['cart_id'] ?>">
                <button type="button" class="qty-minus">-</button>
                <input type="number" name="quantity" value="<?= $r['quantity'] ?>" min="1" max="<?= (int)$r['stock'] ?>">
                <button type="button" class="qty-plus">+</button>
                <button type="submit" name="update_cart" class="btn btn-sm btn-outline" style="border-color:var(--blue-600); color:var(--blue-600); margin-left:6px;">Update</button>
              </form>
              <div style="font-weight:700;"><?= rupiah($r['price'] * $r['quantity']) ?></div>
              <a href="<?= BASE_URL ?>/cart.php?remove=<?= $r['cart_id'] ?>" class="remove-btn confirm-delete" data-msg="Hapus buku ini dari keranjang?">Hapus</a>
            </div>
          <?php endforeach; ?>
        </div>

        <div class="summary-card">
          <h3>Ringkasan Pesanan</h3>
          <div class="summary-row"><span>Subtotal</span><span><?= rupiah($subtotal) ?></span></div>
          <div class="summary-row"><span>Ongkos Kirim</span><span><?= rupiah($shipping) ?></span></div>
          <div class="summary-row total"><span>Total</span><span><?= rupiah($total) ?></span></div>
          <a href="<?= BASE_URL ?>/checkout.php" class="btn btn-primary btn-full" style="margin-top:10px;">Lanjut ke Checkout</a>
        </div>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
