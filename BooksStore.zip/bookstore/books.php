<?php
require_once 'config.php';
$pageTitle = 'Buku';

$categories = $conn->query("SELECT * FROM categories ORDER BY name ASC");
$catList = [];
$catRes = $conn->query("SELECT * FROM categories ORDER BY name ASC");
while ($c = $catRes->fetch_assoc()) $catList[] = $c;

$selectedCat = isset($_GET['category']) ? (int)$_GET['category'] : 0;
$keyword = trim($_GET['q'] ?? '');
$filter = $_GET['filter'] ?? '';

$where = [];
$params = [];
$types = '';

if ($selectedCat > 0) {
    $where[] = 'category_id = ?';
    $params[] = $selectedCat;
    $types .= 'i';
}
if ($keyword !== '') {
    $where[] = '(title LIKE ? OR author LIKE ?)';
    $like = '%' . $keyword . '%';
    $params[] = $like; $params[] = $like;
    $types .= 'ss';
}
if ($filter === 'bestseller') {
    $where[] = "badge = 'Bestseller'";
}

$sql = "SELECT * FROM books";
if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
$sql .= ' ORDER BY created_at DESC';

$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$books = $stmt->get_result();

require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Buku</div>
  <h1>Popular Books</h1>
</div>

<section class="section">
  <div class="container">
    <div class="filter-bar">
      <div class="tabs">
        <a href="<?= BASE_URL ?>/books.php" class="tab-btn <?= $selectedCat===0 && $filter==='' ? 'active' : '' ?>">Semua</a>
        <?php foreach ($catList as $c): ?>
          <a href="<?= BASE_URL ?>/books.php?category=<?= $c['id'] ?>" class="tab-btn <?= $selectedCat===(int)$c['id'] ? 'active' : '' ?>"><?= esc($c['name']) ?></a>
        <?php endforeach; ?>
      </div>
      <form class="search-inline" method="get">
        <?php if ($selectedCat) : ?><input type="hidden" name="category" value="<?= $selectedCat ?>"><?php endif; ?>
        <input type="text" name="q" placeholder="Cari buku..." value="<?= esc($keyword) ?>">
        <button type="submit">🔍</button>
      </form>
    </div>

    <?php if ($books->num_rows === 0): ?>
      <div class="empty-state">
        <div class="icon">📕</div>
        <p>Buku tidak ditemukan. Coba kata kunci atau kategori lain.</p>
      </div>
    <?php else: ?>
      <div class="book-grid">
        <?php while ($book = $books->fetch_assoc()): ?>
          <div class="book-card">
            <div class="cover-wrap">
              <?php if ($book['badge']): ?>
                <span class="badge badge-<?= strtolower($book['badge']) === 'baru' ? 'baru' : 'bestseller' ?>"><?= esc($book['badge']) ?></span>
              <?php endif; ?>
              <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $book['id'] ?>">
                <img src="<?= bookCover($book['cover_image'], $book['title']) ?>" alt="<?= esc($book['title']) ?>">
              </a>
            </div>
            <div class="book-body">
              <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $book['id'] ?>"><h3><?= esc($book['title']) ?></h3></a>
              <div class="author"><?= esc($book['author']) ?></div>
              <div class="rating">★ <span class="count">(<?= number_format($book['rating'],1) ?>)</span></div>
              <div class="price-row">
                <span class="price"><?= rupiah($book['price']) ?></span>
              </div>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php endif; ?>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
