<?php
/**
 * config.php
 * Koneksi database + session + fungsi helper global
 * Letakkan file ini di root project, di-include di semua halaman.
 */

session_start();

// ----------- KONFIGURASI DATABASE -----------
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'nijbook_db');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die('Koneksi database gagal: ' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

// Base URL folder project (sesuaikan jika perlu, dipakai untuk redirect antar level folder)
define('BASE_URL', '/bookstore');

// ----------- HELPER FUNCTIONS -----------

// Format rupiah, contoh: 98000 -> Rp98.000
function rupiah($angka) {
    return 'Rp' . number_format((float)$angka, 0, ',', '.');
}

// Cek apakah user sedang login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Cek apakah user yang login adalah admin
function isAdmin() {
    return isLoggedIn() && $_SESSION['role'] === 'admin';
}

// Paksa harus login, kalau tidak redirect ke login.php
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

// Paksa harus admin, kalau tidak redirect
function requireAdmin() {
    if (!isAdmin()) {
        header('Location: ' . BASE_URL . '/login.php');
        exit;
    }
}

// Hitung jumlah item di keranjang milik user yang sedang login
function cartCount($conn) {
    if (!isLoggedIn()) return 0;
    $uid = (int)$_SESSION['user_id'];
    $res = $conn->query("SELECT COALESCE(SUM(quantity),0) AS total FROM cart WHERE user_id = $uid");
    $row = $res->fetch_assoc();
    return (int)$row['total'];
}

// Amankan output string ke HTML
function esc($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

// Ambil gambar sampul buku, atau placeholder jika kosong
function bookCover($cover, $title) {
    if (!empty($cover) && file_exists(__DIR__ . '/uploads/' . $cover)) {
        return BASE_URL . '/uploads/' . $cover;
    }
    // placeholder generik berbasis judul buku
    return 'https://placehold.co/300x420/1e293b/ffffff?text=' . urlencode($title);
}

// Flash message sederhana (disimpan 1x di session lalu dihapus setelah ditampilkan)
function setFlash($type, $message) {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function getFlash() {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}
