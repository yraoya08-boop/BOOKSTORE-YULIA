<?php
require_once 'config.php';
$pageTitle = 'Beranda';

// Buku unggulan untuk hero (bestseller rating tertinggi)
$featured = $conn->query("SELECT * FROM books ORDER BY badge = 'Bestseller' DESC, rating DESC LIMIT 1")->fetch_assoc();

// Statistik
$totalBooks = $conn->query("SELECT COUNT(*) c FROM books")->fetch_assoc()['c'];
$totalCategories = $conn->query("SELECT COUNT(*) c FROM categories")->fetch_assoc()['c'];

// Kategori (ambil 5 pertama)
$categories = $conn->query("SELECT * FROM categories ORDER BY id ASC LIMIT 5");

// Buku populer
$popularBooks = $conn->query("SELECT * FROM books ORDER BY rating DESC LIMIT 10");

$colorMap = ['blue' => 'cat-blue', 'yellow' => 'cat-yellow', 'green' => 'cat-green', 'purple' => 'cat-purple', 'pink' => 'cat-pink'];

require 'includes/header.php';
?>

<section class="hero">
  <div class="container">
    <div>
      <h1>Find Your<br>Next Favorite<br><span class="accent">Book.</span></h1>
      <p>Temukan ribuan buku pilihan dari berbagai genre terbaik untuk menemani harimu.</p>
      <div class="hero-buttons">
        <a href="<?= BASE_URL ?>/books.php" class="btn btn-primary">Jelajahi Sekarang</a>
        <a href="<?= BASE_URL ?>/categories.php" class="btn btn-outline">Lihat Kategori</a>
      </div>
    </div>

    <?php if ($featured): ?>
    <div class="hero-card">
      <?php if ($featured['badge']): ?>
        <span class="badge badge-<?= strtolower($featured['badge']) === 'baru' ? 'baru' : 'bestseller' ?>"><?= esc($featured['badge']) ?></span>
      <?php endif; ?>
      <button class="wishlist-icon">♡</button>
      <img src="<?= bookCover($featured['cover_image'], $featured['title']) ?>" alt="<?= esc($featured['title']) ?>">
      <h3><?= esc($featured['title']) ?></h3>
      <div class="author"><?= esc($featured['author']) ?></div>
      <div class="rating">★★★★★ <span class="count">(<?= number_format($featured['rating'],1) ?>)</span></div>
      <div class="price"><?= rupiah($featured['price']) ?></div>
      <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $featured['id'] ?>" class="btn btn-primary btn-full">🛒 Beli Sekarang</a>
    </div>
    <?php endif; ?>
  </div>
</section>

<div class="container">
  <div class="stats-bar">
    <div class="stat-item"><span class="stat-icon">📚</span><div><div class="stat-num"><?= number_format($totalBooks) ?>+</div><div class="stat-label">Buku Tersedia</div></div></div>
    <div class="stat-item"><span class="stat-icon">🏛️</span><div><div class="stat-num">150+</div><div class="stat-label">Penerbit</div></div></div>
    <div class="stat-item"><span class="stat-icon">⭐</span><div><div class="stat-num">4.9★</div><div class="stat-label">Rating Toko</div></div></div>
  </div>
</div>

<section class="section">
  <div class="container">
    <div class="section-header">
      <h2>Explore Categories</h2>
      <a href="<?= BASE_URL ?>/categories.php" class="section-link">Lihat Semua →</a>
    </div>
    <div class="category-grid">
      <?php while ($cat = $categories->fetch_assoc()): ?>
        <a href="<?= BASE_URL ?>/books.php?category=<?= $cat['id'] ?>" class="category-card <?= $colorMap[$cat['color']] ?? 'cat-blue' ?>">
          <div class="icon-circle"><?= $cat['icon'] ?></div>
          <h3><?= esc($cat['name']) ?></h3>
          <?php $c = $conn->query("SELECT COUNT(*) c FROM books WHERE category_id=" . (int)$cat['id'])->fetch_assoc()['c']; ?>
          <p><?= $c ?> Buku</p>
        </a>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<section class="section" style="padding-top:0;">
  <div class="container">
    <div class="section-header">
      <h2>Popular Books</h2>
      <a href="<?= BASE_URL ?>/books.php" class="section-link">Lihat Semua →</a>
    </div>
    <div class="book-grid">
      <?php while ($book = $popularBooks->fetch_assoc()): ?>
        <div class="book-card">
          <div class="cover-wrap">
            <?php if ($book['badge']): ?>
              <span class="badge badge-<?= strtolower($book['badge']) === 'baru' ? 'baru' : 'bestseller' ?>"><?= esc($book['badge']) ?></span>
            <?php endif; ?>
            <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $book['id'] ?>">
              <img src="<?= bookCover($book['cover_image'], $book['title']) ?>" alt="<?= esc($book['title']) ?>">
            </a>
          </div>
          <div class="book-body">
            <a href="<?= BASE_URL ?>/book_detail.php?id=<?= $book['id'] ?>"><h3><?= esc($book['title']) ?></h3></a>
            <div class="author"><?= esc($book['author']) ?></div>
            <div class="rating">★ <span class="count">(<?= number_format($book['rating'],1) ?>)</span></div>
            <div class="price-row">
              <span class="price"><?= rupiah($book['price']) ?></span>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
