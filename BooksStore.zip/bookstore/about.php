<?php
require_once 'config.php';
$pageTitle = 'Tentang Kami';
require 'includes/header.php';
?>

<div class="container page-header">
  <div class="breadcrumb"><a href="<?= BASE_URL ?>/index.php">Beranda</a> / Tentang Kami</div>
  <h1>Tentang Nijbook</h1>
</div>

<section class="section">
  <div class="container" style="max-width:820px;">
    <div class="card-box">
      <p style="line-height:1.9; color:#374151; margin-bottom:16px;">
        Nijbook adalah toko buku online terpercaya yang hadir untuk menemani perjalanan literasi setiap orang.
        Kami percaya bahwa setiap buku memiliki kekuatan untuk mengubah cara pandang, menambah wawasan, dan
        menginspirasi kehidupan yang lebih baik.
      </p>
      <p style="line-height:1.9; color:#374151; margin-bottom:16px;">
        Berdiri sejak beberapa tahun lalu, Nijbook telah bekerja sama dengan lebih dari 150 penerbit dan
        menyediakan lebih dari 20.000 judul buku dari berbagai genre — mulai dari fiksi, non-fiksi, bisnis,
        pengembangan diri, hingga romance.
      </p>
      <p style="line-height:1.9; color:#374151;">
        Misi kami sederhana: membuat buku berkualitas mudah dijangkau oleh siapa saja, kapan saja, di mana saja,
        dengan layanan yang cepat, aman, dan nyaman — termasuk opsi pembayaran di tempat (Payment at Delivery)
        untuk kemudahan pelanggan kami.
      </p>
    </div>

    <div class="stat-cards" style="margin-top:10px;">
      <div class="stat-card"><div class="num">20K+</div><div class="lbl">Buku Tersedia</div></div>
      <div class="stat-card"><div class="num">150+</div><div class="lbl">Penerbit Mitra</div></div>
      <div class="stat-card"><div class="num">4.9★</div><div class="lbl">Rating Toko</div></div>
      <div class="stat-card"><div class="num">10K+</div><div class="lbl">Pelanggan Puas</div></div>
    </div>
  </div>
</section>

<?php require 'includes/footer.php'; ?>
