<?php
// Endpoint autocomplete: mengambil saran langsung dari tabel books.
require_once __DIR__ . '/koneksi.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$keyword = trim($_GET['q'] ?? '');
if (mb_strlen($keyword, 'UTF-8') < 2) {
    echo json_encode([], JSON_UNESCAPED_UNICODE);
    exit;
}

try {
    $like = '%' . $keyword . '%';
    $stmt = $conn->prepare(
        "SELECT id, judul, penulis, kategori, gambar, harga
         FROM books
         WHERE judul LIKE :judul OR penulis LIKE :penulis OR kategori LIKE :kategori
         ORDER BY CASE WHEN judul LIKE :awal THEN 0 ELSE 1 END, judul ASC
         LIMIT 8"
    );
    $stmt->execute([
        ':judul' => $like,
        ':penulis' => $like,
        ':kategori' => $like,
        ':awal' => $keyword . '%'
    ]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Pencarian sementara tidak dapat dilakukan.']);
}
