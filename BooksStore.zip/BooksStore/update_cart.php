<?php
session_start();
require_once "koneksi.php";

if (!isset($_SESSION["login"]) || $_SESSION["login"] !== true || ($_SESSION["role"] ?? "") !== "user") {
    echo json_encode(["status" => "error", "message" => "Unauthorized"]);
    exit;
}

$userId = (int)$_SESSION["user_id"];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $cartId = filter_input(INPUT_POST, "cart_id", FILTER_VALIDATE_INT);
    $jumlah = filter_input(INPUT_POST, "jumlah", FILTER_VALIDATE_INT);

    if ($cartId && $jumlah !== false) {
        if ($jumlah < 1) $jumlah = 1;
        if ($jumlah > 99) $jumlah = 99;

        $update = $conn->prepare("
            UPDATE cart
            SET jumlah = ?
            WHERE id = ?
            AND user_id = ?
        ");
        $update->execute([$jumlah, $cartId, $userId]);

        echo json_encode(["status" => "success"]);
        exit;
    }
}

echo json_encode(["status" => "error", "message" => "Invalid request"]);