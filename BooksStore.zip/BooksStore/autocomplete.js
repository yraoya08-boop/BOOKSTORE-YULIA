document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('bookAutocompleteForm');
  const input = document.getElementById('bookAutocompleteInput');
  const results = document.getElementById('bookAutocompleteResults');
  if (!form || !input || !results) return;

  let debounceTimer;
  let activeController = null;

  const closeResults = () => {
    results.classList.remove('show');
    results.innerHTML = '';
    input.setAttribute('aria-expanded', 'false');
  };

  const makeSuggestion = (book) => {
    const link = document.createElement('a');
    link.className = 'autocomplete-item';
    link.href = `deskripsi.php?id=${encodeURIComponent(book.id)}`;
    link.setAttribute('role', 'option');

    if (book.gambar) {
      const img = document.createElement('img');
      img.className = 'autocomplete-cover';
      img.src = 'image/' + encodeURIComponent(book.gambar).replace(/%2F/gi, '/');
      img.alt = '';
      img.loading = 'lazy';
      img.onerror = () => { img.style.display = 'none'; };
      link.appendChild(img);
    }

    const info = document.createElement('span');
    info.className = 'autocomplete-info';
    const title = document.createElement('strong');
    title.textContent = book.judul || 'Tanpa judul';
    const author = document.createElement('small');
    author.textContent = book.penulis || book.kategori || 'Informasi penulis tidak tersedia';
    info.append(title, author);
    link.appendChild(info);

    const arrow = document.createElement('i');
    arrow.className = 'fa-solid fa-arrow-up-right-from-square autocomplete-arrow';
    link.appendChild(arrow);
    return link;
  };

  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    const keyword = input.value.trim();
    if (keyword.length < 2) {
      if (activeController) activeController.abort();
      closeResults();
      return;
    }

    debounceTimer = setTimeout(async () => {
      if (activeController) activeController.abort();
      activeController = new AbortController();
      results.innerHTML = '<div class="autocomplete-message">Mencari buku...</div>';
      results.classList.add('show');
      input.setAttribute('aria-expanded', 'true');

      try {
        const response = await fetch(`search_suggestions.php?q=${encodeURIComponent(keyword)}`, {
          headers: { 'Accept': 'application/json' },
          signal: activeController.signal
        });
        if (!response.ok) throw new Error('Gagal mengambil saran');
        const books = await response.json();
        results.innerHTML = '';

        if (!Array.isArray(books) || books.length === 0) {
          results.innerHTML = '<div class="autocomplete-message">Buku tidak ditemukan.</div>';
          return;
        }
        books.forEach(book => results.appendChild(makeSuggestion(book)));
      } catch (error) {
        if (error.name !== 'AbortError') {
          results.innerHTML = '<div class="autocomplete-message">Tidak dapat memuat saran. Coba lagi.</div>';
        }
      }
    }, 250);
  });

  input.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeResults();
    if (event.key === 'ArrowDown') {
      const first = results.querySelector('.autocomplete-item');
      if (first) { event.preventDefault(); first.focus(); }
    }
  });

  document.addEventListener('click', (event) => {
    if (!form.contains(event.target)) closeResults();
  });
  form.addEventListener('submit', () => closeResults());
});
